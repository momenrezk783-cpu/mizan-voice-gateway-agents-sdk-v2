import assert from 'node:assert/strict';

// Arabic letters only (matches guard.ts)
const AR = '\u0621-\u063A\u0641-\u064A\u0671-\u06D3';
const L  = `(?<![${AR}])`;
const R  = `(?![${AR}])`;
const re = (src) => new RegExp(src, 'gu');

const RULES = [
  { label: 'ya_fandem',      rx: re(`${L}يا\\s*(?:أ|ا)?فندم${R}`), to: '' },
  { label: 'fandem',         rx: re(`${L}(?:أ|ا)?فندم${R}`),        to: '' },
  { label: 'vocative_title', rx: re(`${L}يا\\s*(?:باشا|بيه|بك|هانم|(?:أ|ا)ستاذ[ةه]?|دكتور[ةه]?|مهندس[ةه]?)${R}`), to: '' },
  { label: 'hadretak_me3ak', rx: re(`مع\\s+حضرتك`),                to: 'معاك' },
  { label: 'hadretak_3ndak', rx: re(`عند\\s+حضرتك`),               to: 'عندك' },
  { label: 'hadretak_lak',   rx: re(`${L}لحضرتك${R}`),             to: 'ليك'  },
  { label: 'hadretak_bak',   rx: re(`${L}بحضرتك${R}`),             to: 'بيك'  },
  { label: 'hadretak_om',    rx: re(`${L}حضرتكم${R}`),             to: 'إنتو' },
  { label: 'hadretak_base',  rx: re(`${L}([وف]?)حضرتك${R}`),       to: '$1إنت' },
  { label: 'sayadtak_pl',    rx: re(`${L}(?:سيادتكم|سعادتكم)${R}`), to: 'إنتو' },
  { label: 'sayadtak_sg',    rx: re(`${L}([وف]?)(?:سيادتك|سعادتك)${R}`), to: '$1إنت' },
];

function sanitize(input) {
  let text = input;
  const violations = [];
  for (const r of RULES) {
    const next = text.replace(r.rx, r.to);
    if (next !== text) violations.push(r.label);
    text = next;
  }
  if (violations.length) {
    text = text.replace(/\s{2,}/g, ' ').replace(/\s+([،,.!؟?؛])/g, '$1').replace(/^[\s،,]+/, '');
  }
  return { text: text.trim(), violations };
}

function normalizeDigits(s) {
  return s.replace(/[\u0660-\u0669\u06F0-\u06F9]/g, d => {
    const c = d.charCodeAt(0);
    return String(c - (c >= 0x06f0 ? 0x06f0 : 0x0660));
  });
}

const VALIDATORS = {
  text: (v) => { const t = v.trim().replace(/\s+/g,' '); return t.length>=2&&t.length<=160?t:null; },
  phone_eg: (v) => {
    let d = normalizeDigits(v).replace(/[^\d+]/g,'');
    d = d.replace(/^(\+20|0020|20)/,'0');
    if(/^1[0125]\d{8}$/.test(d)) d='0'+d;
    return /^01[0125]\d{8}$/.test(d)?d:null;
  },
  email: (v) => { const e=v.trim().toLowerCase(); return /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(e)?e:null; },
  date_iso: (v, today) => {
    const d = normalizeDigits(v).trim();
    if(!/^\d{4}-\d{2}-\d{2}$/.test(d)) return null;
    const p=new Date(`${d}T00:00:00Z`);
    if(Number.isNaN(p.getTime())||p.toISOString().slice(0,10)!==d) return null;
    return d>=today?d:null;
  },
  time_hhmm: (v) => {
    const m=normalizeDigits(v).trim().match(/^(\d{1,2}):(\d{2})$/);
    if(!m) return null;
    const h=Number(m[1]),mi=Number(m[2]);
    return h<=23&&mi<=59?`${String(h).padStart(2,'0')}:${m[2]}`:null;
  },
};

const MANUAL = {
  GREETING: ['CLOSING'],
  DATA_COLLECTION: ['CLOSING'],
  ACTION: ['DATA_COLLECTION','CLOSING'],
  CLOSING: ['DATA_COLLECTION'],
  ENDED: [],
};

let passed = 0, failed = 0;
function test(name, fn) {
  try { fn(); console.log(`  ✓ ${name}`); passed++; }
  catch(e) { console.error(`  ✗ ${name}\n    ${e.message}`); failed++; }
}

console.log('\n── Guard: honorific sanitizer ──');

test('passes clean Egyptian Arabic unchanged', () => {
  const { text, violations } = sanitize('أهلاً بيك يا أحمد، إزيك؟');
  assert.equal(text, 'أهلاً بيك يا أحمد، إزيك؟');
  assert.equal(violations.length, 0);
});
test('removes يا فندم', () => {
  const { text, violations } = sanitize('تمام يا فندم، هساعدك دلوقتي.');
  assert.ok(!text.includes('فندم'), `still contains فندم: "${text}"`);
  assert.ok(violations.includes('ya_fandem'));
});
test('removes فندم standalone', () => {
  const { text } = sanitize('أيوه فندم بكل سرور.');
  assert.ok(!text.includes('فندم'), `still contains فندم: "${text}"`);
});
test('replaces حضرتك → إنت', () => {
  const { text, violations } = sanitize('حضرتك عايز إيه؟');
  assert.ok(text.includes('إنت'), `expected إنت in "${text}"`);
  assert.ok(violations.includes('hadretak_base'));
});
test('replaces لحضرتك → ليك', () => {
  const { text } = sanitize('هبعتلك من حضرتك الرسالة دلوقتي.');
  assert.ok(!text.includes('حضرتك'), `still contains حضرتك in "${text}"`);
});
test('replaces مع حضرتك → معاك', () => {
  const { text } = sanitize('مع حضرتك شوية وقت؟');
  assert.ok(text.includes('معاك'), `expected معاك in "${text}"`);
});
test('replaces سيادتك → إنت', () => {
  const { text } = sanitize('وسيادتك هتيجي إمتى؟');
  assert.ok(!text.includes('سيادتك'), `still contains سيادتك: "${text}"`);
});
test('removes يا دكتور / يا أستاذ as vocative', () => {
  for (const phrase of ['يا دكتور، تفضل', 'يا أستاذ معلش', 'يا مهندس إزيك']) {
    const { text } = sanitize(phrase);
    assert.ok(!text.match(/يا\s+(دكتور|أستاذ|مهندس)/), `vocative not removed in: "${text}"`);
  }
});
test('leaves punctuation intact after removal', () => {
  const { text } = sanitize('تمام يا فندم، هساعدك.');
  assert.ok(!text.startsWith('،'), `leading comma: "${text}"`);
  assert.ok(!text.startsWith(' '), `leading space: "${text}"`);
});
test('handles multiple violations in one sentence', () => {
  const { violations } = sanitize('حضرتك وسيادتك يا فندم.');
  assert.ok(violations.length >= 2);
});

console.log('\n── Slot validators ──');
const TODAY = '2025-01-15';

test('phone_eg: accepts 010 mobile', () => { assert.equal(VALIDATORS.phone_eg('01012345678'), '01012345678'); });
test('phone_eg: accepts +20 prefix', () => { assert.equal(VALIDATORS.phone_eg('+201012345678'), '01012345678'); });
test('phone_eg: accepts 20 prefix',  () => { assert.equal(VALIDATORS.phone_eg('201012345678'), '01012345678'); });
test('phone_eg: accepts Arabic-Indic digits', () => { assert.equal(VALIDATORS.phone_eg('٠١٠١٢٣٤٥٦٧٨'), '01012345678'); });
test('phone_eg: rejects invalid prefix 09', () => { assert.equal(VALIDATORS.phone_eg('09012345678'), null); });
test('phone_eg: rejects too-short number',  () => { assert.equal(VALIDATORS.phone_eg('0101234'), null); });
test('phone_eg: accepts 011 prefix', () => { assert.equal(VALIDATORS.phone_eg('01112345678'), '01112345678'); });
test('phone_eg: accepts 012 prefix', () => { assert.equal(VALIDATORS.phone_eg('01212345678'), '01212345678'); });
test('phone_eg: accepts 015 prefix', () => { assert.equal(VALIDATORS.phone_eg('01512345678'), '01512345678'); });

test('email: normalises to lowercase',  () => { assert.equal(VALIDATORS.email('Ahmed@Gmail.COM'), 'ahmed@gmail.com'); });
test('email: rejects missing @',         () => { assert.equal(VALIDATORS.email('noemail.com'), null); });
test('email: rejects single-char TLD',  () => { assert.equal(VALIDATORS.email('a@b.c'), null); });

test('date_iso: accepts today',          () => { assert.equal(VALIDATORS.date_iso(TODAY, TODAY), TODAY); });
test('date_iso: accepts future date',    () => { assert.equal(VALIDATORS.date_iso('2025-12-31', TODAY), '2025-12-31'); });
test('date_iso: rejects past date',      () => { assert.equal(VALIDATORS.date_iso('2024-01-01', TODAY), null); });
test('date_iso: rejects month 13',       () => { assert.equal(VALIDATORS.date_iso('2025-13-01', TODAY), null); });
test('date_iso: rejects free text',      () => { assert.equal(VALIDATORS.date_iso('الخميس الجاي', TODAY), null); });
test('date_iso: accepts Arabic-Indic',   () => { assert.equal(VALIDATORS.date_iso('٢٠٢٥-٠١-١٥', TODAY), '2025-01-15'); });

test('time_hhmm: accepts 9:30',          () => { assert.equal(VALIDATORS.time_hhmm('9:30'), '09:30'); });
test('time_hhmm: accepts 23:59',         () => { assert.equal(VALIDATORS.time_hhmm('23:59'), '23:59'); });
test('time_hhmm: rejects 24:00',         () => { assert.equal(VALIDATORS.time_hhmm('24:00'), null); });
test('time_hhmm: rejects free text',     () => { assert.equal(VALIDATORS.time_hhmm('الساعة أربعة'), null); });

test('text: accepts normal string',      () => { assert.equal(VALIDATORS.text('حجز كشف عام'), 'حجز كشف عام'); });
test('text: rejects single character',   () => { assert.equal(VALIDATORS.text('أ'), null); });

console.log('\n── State machine: manual transition guards ──');

test('GREETING may only go to CLOSING manually',       () => { assert.deepEqual(MANUAL['GREETING'], ['CLOSING']); });
test('DATA_COLLECTION may only go to CLOSING manually',() => { assert.deepEqual(MANUAL['DATA_COLLECTION'], ['CLOSING']); });
test('ACTION may go to DATA_COLLECTION or CLOSING',    () => { assert.ok(MANUAL['ACTION'].includes('DATA_COLLECTION') && MANUAL['ACTION'].includes('CLOSING')); });
test('CLOSING may go to DATA_COLLECTION (new request)',() => { assert.ok(MANUAL['CLOSING'].includes('DATA_COLLECTION')); });
test('ENDED has no manual transitions',                () => { assert.deepEqual(MANUAL['ENDED'], []); });

console.log(`\n${'─'.repeat(50)}`);
console.log(`${passed + failed} tests: ${passed} passed, ${failed} failed`);
if (failed > 0) process.exit(1);
