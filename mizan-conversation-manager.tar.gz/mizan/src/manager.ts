// Conversation Manager core. Pure TypeScript (no Workers APIs) → unit-testable.
//
// DIVISION OF LABOUR
//   code  : owns state, validates data, enforces transition guards, runs side-effects
//   LLM   : decides what to SAY and which tool to call; cannot move the call into a state the
//           guards don't allow, cannot confirm data it hasn't read back, cannot pass action params.

import type { CallContext, CallState, IntentSpec, SlotSpec, ValidatorName } from './types';

export interface SlotValue {
  value: string;
  confirmed: boolean;
  source: 'caller' | 'caller_id' | 'crm';
  setAtTurn: number; // caller-turn counter when the value was last set
}

export interface Session {
  state: CallState;
  intent: string | null;
  intentFresh: boolean; // a new intent was set since we entered CLOSING
  slots: Record<string, SlotValue>;
  slotFailures: Record<string, number>;
  actionResult: { ok: boolean; detail: string } | null;
  actionCache: Record<string, { ok: boolean; detail: string }>; // idempotency: successes only
  totalTurns: number; // caller turns
  turnsInState: number;
  trace: Array<{ state: CallState; atTurn: number; ts: number; via: 'init' | 'auto' | 'model' }>;
  endRequest: { reason: string } | null;
  handoff: { reason: string; sent: boolean } | null;
}

export function newSession(): Session {
  return {
    state: 'GREETING',
    intent: null,
    intentFresh: false,
    slots: {},
    slotFailures: {},
    actionResult: null,
    actionCache: {},
    totalTurns: 0,
    turnsInState: 0,
    trace: [{ state: 'GREETING', atTurn: 0, ts: Date.now(), via: 'init' }],
    endRequest: null,
    handoff: null,
  };
}

// ------------------------------------------------------------------------------------------
// Default intent catalogue (tenants can override via TenantConfig.intents)
// ------------------------------------------------------------------------------------------
const NAME: SlotSpec = { name: 'name', label: "caller's first name", required: true, validator: 'text', prefill: 'crm_name', carryOver: true };
const PHONE: SlotSpec = { name: 'phone', label: 'mobile number', required: true, validator: 'phone_eg', needsConfirm: true, prefill: 'caller_id', carryOver: true };

export const DEFAULT_INTENTS: IntentSpec[] = [
  {
    id: 'book_appointment',
    label: 'book an appointment / consultation',
    action: 'book_appointment',
    slots: [
      NAME,
      PHONE,
      { name: 'date', label: 'preferred date (YYYY-MM-DD)', required: true, validator: 'date_iso', needsConfirm: true },
      { name: 'time', label: 'preferred time (HH:MM, 24h)', required: true, validator: 'time_hhmm', needsConfirm: true },
      { name: 'email', label: 'email — OPTIONAL, only if the caller offers it', required: false, validator: 'email', needsConfirm: true, prefill: 'crm_email', carryOver: true },
    ],
  },
  {
    id: 'callback_request',
    label: 'wants a human to call them back',
    action: 'request_callback',
    slots: [NAME, PHONE, { name: 'topic', label: 'what the callback is about (short)', required: true, validator: 'text' }],
  },
  {
    id: 'complaint',
    label: 'complaint or problem with a previous service',
    action: 'create_ticket',
    slots: [NAME, PHONE, { name: 'issue', label: 'one-sentence description of the problem', required: true, validator: 'text' }],
  },
  { id: 'inquiry', label: 'general question about the business', action: null, slots: [] },
];

// ------------------------------------------------------------------------------------------
// Slot validation / normalisation
// ------------------------------------------------------------------------------------------
export function normalizeDigits(s: string): string {
  return s.replace(/[\u0660-\u0669\u06F0-\u06F9]/g, (d) => {
    const c = d.charCodeAt(0);
    return String(c - (c >= 0x06f0 ? 0x06f0 : 0x0660));
  });
}

const VALIDATORS: Record<ValidatorName, (raw: string, todayIso: string) => string | null> = {
  text: (v) => {
    const t = v.trim().replace(/\s+/g, ' ');
    return t.length >= 2 && t.length <= 160 ? t : null;
  },
  phone_eg: (v) => {
    // Egyptian mobiles: 010/011/012/015 + 8 digits. (Landlines intentionally out of scope.)
    let d = normalizeDigits(v).replace(/[^\d+]/g, '');
    d = d.replace(/^(\+20|0020|20)/, '0');
    if (/^1[0125]\d{8}$/.test(d)) d = '0' + d;
    return /^01[0125]\d{8}$/.test(d) ? d : null;
  },
  email: (v) => {
    const e = v.trim().toLowerCase();
    return /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(e) ? e : null;
  },
  date_iso: (v, todayIso) => {
    const d = normalizeDigits(v).trim();
    if (!/^\d{4}-\d{2}-\d{2}$/.test(d)) return null;
    const parsed = new Date(`${d}T00:00:00Z`);
    if (Number.isNaN(parsed.getTime()) || parsed.toISOString().slice(0, 10) !== d) return null;
    return d >= todayIso ? d : null; // no past dates
  },
  time_hhmm: (v) => {
    const m = normalizeDigits(v).trim().match(/^(\d{1,2}):(\d{2})$/);
    if (!m) return null;
    const h = Number(m[1]);
    const mi = Number(m[2]);
    return h <= 23 && mi <= 59 ? `${String(h).padStart(2, '0')}:${m[2]}` : null;
  },
};

export function validateSlot(validator: ValidatorName, raw: string, todayIso: string): string | null {
  return VALIDATORS[validator](raw, todayIso);
}

// ------------------------------------------------------------------------------------------
// State machine
// ------------------------------------------------------------------------------------------
const specOf = (s: Session, intents: IntentSpec[]) => intents.find((i) => i.id === s.intent) ?? null;
const missingRequired = (s: Session, sp: IntentSpec) => sp.slots.filter((x) => x.required && !s.slots[x.name]);
const awaitingConfirm = (s: Session, sp: IntentSpec) => sp.slots.filter((x) => x.needsConfirm && s.slots[x.name] && !s.slots[x.name].confirmed);

function go(s: Session, to: CallState, via: 'auto' | 'model'): void {
  if (to === s.state) return;
  if (to === 'DATA_COLLECTION') s.actionResult = null; // re-collecting invalidates the last outcome
  if (to === 'CLOSING') s.intentFresh = false;
  s.state = to;
  s.turnsInState = 0;
  s.trace.push({ state: to, atTurn: s.totalTurns, ts: Date.now(), via });
}

/** Deterministic transitions. The LLM never has to "decide" these — less to get wrong. */
export function autoAdvance(s: Session, intents: IntentSpec[]): CallState[] {
  const moved: CallState[] = [];
  for (let i = 0; i < 3; i++) {
    const sp = specOf(s, intents);
    let next: CallState | null = null;
    if (s.state === 'GREETING' && sp) next = 'DATA_COLLECTION';
    else if (s.state === 'DATA_COLLECTION' && sp && missingRequired(s, sp).length === 0 && awaitingConfirm(s, sp).length === 0) next = 'ACTION';
    else if (s.state === 'ACTION' && s.actionResult?.ok) next = 'CLOSING';
    if (!next) break;
    go(s, next, 'auto');
    moved.push(next);
  }
  return moved;
}

const MANUAL: Record<CallState, CallState[]> = {
  GREETING: ['CLOSING'],
  DATA_COLLECTION: ['CLOSING'],
  ACTION: ['DATA_COLLECTION', 'CLOSING'],
  CLOSING: ['DATA_COLLECTION'],
  ENDED: [],
};

export function markHandoff(s: Session, reason: string): void {
  s.handoff = { reason, sent: false };
  go(s, 'ENDED', 'model');
}

export function markEnd(s: Session, reason: string): void {
  s.endRequest = { reason };
  go(s, 'ENDED', 'model');
}

function setIntent(s: Session, ctx: CallContext, intents: IntentSpec[], id: string): string | null {
  const sp = intents.find((i) => i.id === id);
  if (!sp) return `Unknown intent "${id}". Valid: ${intents.map((i) => i.id).join(', ')}.`;
  if (s.intent === id && s.state !== 'CLOSING') return null;
  const keep = new Set(sp.slots.filter((x) => x.carryOver).map((x) => x.name));
  for (const k of Object.keys(s.slots)) if (!keep.has(k)) delete s.slots[k];
  s.slotFailures = {};
  s.intent = id;
  s.intentFresh = true;
  s.actionResult = null;
  for (const slot of sp.slots) {
    if (s.slots[slot.name] || !slot.prefill) continue;
    const raw = slot.prefill === 'caller_id' ? ctx.callerPhone : slot.prefill === 'crm_name' ? ctx.caller.firstName : null;
    const val = raw ? validateSlot(slot.validator, raw, ctx.clock.todayIso) : null;
    if (val) s.slots[slot.name] = { value: val, confirmed: !slot.needsConfirm, source: slot.prefill === 'caller_id' ? 'caller_id' : 'crm', setAtTurn: s.totalTurns };
  }
  return null;
}

// ------------------------------------------------------------------------------------------
// <live_state> — re-rendered every hop, so the model always knows its CURRENT objective
// ------------------------------------------------------------------------------------------
const OBJECTIVE: Record<CallState, string> = {
  GREETING: 'Open warmly and find out why they called. Collect no personal data yet. As soon as the reason is clear → update_slots(intent=…).',
  DATA_COLLECTION: 'Collect ONLY the missing items, one per turn. Read back flagged items once. Never re-ask known items.',
  ACTION: 'Execute the request: short filler line → perform_action → report the real outcome in one or two sentences.',
  CLOSING: 'One-sentence recap, ask ONCE if they need anything else, warm goodbye, then end_call.',
  ENDED: 'The call is over. Say nothing more.',
};
const SOFT_LIMIT: Record<CallState, number> = { GREETING: 3, DATA_COLLECTION: 12, ACTION: 4, CLOSING: 4, ENDED: 0 };

export function renderLiveState(s: Session, ctx: CallContext, intents: IntentSpec[]): string {
  const sp = specOf(s, intents);
  const L: string[] = [
    '<live_state>',
    `TODAY: ${ctx.clock.todayIso} (${ctx.clock.weekday}) · LOCAL_TIME: ${ctx.clock.localTime} ${ctx.clock.timezone}`,
    `CURRENT_STATE: ${s.state}`,
    `OBJECTIVE: ${OBJECTIVE[s.state]}`,
  ];
  if (s.state === 'GREETING') {
    L.push('KNOWN_INTENTS: ' + intents.map((i) => `${i.id} (${i.label})`).join('; '));
  }
  if (sp) {
    L.push(`INTENT: ${sp.id}`);
    const known = sp.slots.filter((x) => s.slots[x.name]);
    if (known.length) {
      L.push('KNOWN (never ask again): ' + known.map((x) => `${x.name}="${s.slots[x.name].value}"${s.slots[x.name].confirmed ? ' ✓' : ''}`).join(', '));
    }
    const missing = missingRequired(s, sp);
    if (s.state === 'DATA_COLLECTION') {
      L.push('MISSING (ask in this order): ' + (missing.map((x) => `${x.name} — ${x.label}`).join('; ') || 'none'));
      const aw = awaitingConfirm(s, sp);
      if (aw.length) {
        L.push('AWAITING_CONFIRMATION: ' + aw.map((x) => `${x.name}="${s.slots[x.name].value}" (${s.slots[x.name].source === 'caller_id' ? 'from caller ID — ask whether to use it' : 'read back once'})`).join('; '));
      }
      const failed = Object.entries(s.slotFailures).map(([k, n]) => `${k} (${n}×${n >= 2 ? ' → CHANGE STRATEGY' : ''})`);
      if (failed.length) L.push('FAILED_VALIDATION: ' + failed.join(', '));
    }
    if (s.state === 'ACTION') L.push(sp.action ? `ACTION: ${sp.action} (call perform_action)` : 'ACTION: none — answer from <business_knowledge>, then advance_state(CLOSING)');
  }
  if (s.actionResult) L.push(`LAST_ACTION_RESULT: ${s.actionResult.ok ? 'OK' : 'FAILED'} — ${s.actionResult.detail}`);
  L.push(`TURNS_IN_STATE: ${s.turnsInState} (soft limit ${SOFT_LIMIT[s.state]})`);
  if (s.turnsInState > SOFT_LIMIT[s.state] && s.state !== 'ENDED') {
    L.push('STALLED: too long in this state. Change approach NOW — name the blocker, offer a human callback (intent callback_request) or transfer_to_human.');
  }
  L.push('</live_state>');
  return L.join('\n');
}

// ------------------------------------------------------------------------------------------
// Tools
// ------------------------------------------------------------------------------------------
export function buildTools(intents: IntentSpec[]) {
  const actions = intents.map((i) => i.action).filter((a): a is string => !!a);
  return [
    {
      name: 'update_slots',
      description:
        'Record what the caller said. Call in the SAME response as your spoken reply when the caller states why they called (intent), gives or corrects a detail (slots), or agrees to a read-back (confirmed_slots). Formats: phone digits only; date YYYY-MM-DD (resolve relative dates from TODAY); time HH:MM 24h; email lowercase with @ and dots. confirmed_slots only for items you read back in an EARLIER turn that the caller then agreed to.',
      input_schema: {
        type: 'object',
        properties: {
          intent: { type: 'string', enum: intents.map((i) => i.id) },
          slots: { type: 'object', additionalProperties: { type: 'string' } },
          confirmed_slots: { type: 'array', items: { type: 'string' } },
        },
      },
    },
    {
      name: 'advance_state',
      description: 'Manual transitions only: any→CLOSING, ACTION→DATA_COLLECTION (action failed because of the data), CLOSING→DATA_COLLECTION (after update_slots with the new intent). Normal progress is automatic.',
      input_schema: {
        type: 'object',
        properties: { to: { type: 'string', enum: ['DATA_COLLECTION', 'CLOSING'] }, reason: { type: 'string' } },
        required: ['to'],
      },
    },
    {
      name: 'perform_action',
      description: 'Run the business action for the current intent using the confirmed data. Only valid in ACTION. You cannot pass parameters. Say a short filler line first.',
      input_schema: { type: 'object', properties: { action: { type: 'string', enum: actions } }, required: ['action'] },
    },
    {
      name: 'transfer_to_human',
      description: 'Hand the call to a human. Say the short handoff line first.',
      input_schema: { type: 'object', properties: { reason: { type: 'string' } }, required: ['reason'] },
    },
    {
      name: 'end_call',
      description: 'End the call. Only from CLOSING, with your goodbye written in the same response.',
      input_schema: { type: 'object', properties: { reason: { type: 'string' } }, required: ['reason'] },
    },
  ];
}

export interface ActionRunResult {
  ok: boolean;
  detail: string;
}

export interface ToolDeps {
  ctx: CallContext;
  intents: IntentSpec[];
  runAction(action: string, slots: Record<string, string>, idempotencyKey: string): Promise<ActionRunResult>;
  canTransfer(): boolean;
}

export interface ToolOutcome {
  content: string; // JSON string handed back to the model as the tool_result
  isError: boolean;
  rejected?: number;
}

const ok = (o: Record<string, unknown>, rejected = 0): ToolOutcome => ({ content: JSON.stringify({ ok: true, ...o }), isError: false, rejected });
const fail = (error: string, extra: Record<string, unknown> = {}): ToolOutcome => ({ content: JSON.stringify({ ok: false, error, ...extra }), isError: true });

function snapshot(s: Session, intents: IntentSpec[]) {
  const sp = specOf(s, intents);
  const hint =
    s.state === 'DATA_COLLECTION' && sp
      ? missingRequired(s, sp)[0]
        ? `Ask next for: ${missingRequired(s, sp)[0].label}`
        : awaitingConfirm(s, sp).length
          ? `Read back for confirmation: ${awaitingConfirm(s, sp).map((x) => x.name).join(', ')}`
          : ''
      : s.state === 'ACTION'
        ? sp?.action
          ? 'All data ready. Say a short filler line, then call perform_action.'
          : 'Answer from business knowledge, then advance_state(CLOSING).'
        : s.state === 'CLOSING'
          ? 'Recap in one sentence, ask once if they need anything else, then goodbye + end_call.'
          : '';
  return {
    state: s.state,
    intent: s.intent,
    known: Object.fromEntries(Object.entries(s.slots).map(([k, v]) => [k, { value: v.value, confirmed: v.confirmed }])),
    missing: sp ? missingRequired(s, sp).map((x) => x.name) : [],
    awaiting_confirmation: sp ? awaitingConfirm(s, sp).map((x) => x.name) : [],
    hint,
  };
}

const fnv = (str: string) => {
  let h = 0x811c9dc5;
  for (let i = 0; i < str.length; i++) h = Math.imul(h ^ str.charCodeAt(i), 0x01000193);
  return (h >>> 0).toString(16);
};

export async function executeTool(d: ToolDeps, s: Session, name: string, input: Record<string, unknown>): Promise<ToolOutcome> {
  if (s.state === 'ENDED') return fail('The call has ended.');
  switch (name) {
    case 'update_slots': {
      if (typeof input.intent === 'string') {
        const err = setIntent(s, d.ctx, d.intents, input.intent);
        if (err) return fail(err);
        if (s.state === 'ACTION') go(s, 'DATA_COLLECTION', 'model'); // new request mid-action → collect again
      }
      const sp = specOf(s, d.intents);
      const rejected: Record<string, string> = {};
      const accepted: string[] = [];
      const slots = (input.slots ?? {}) as Record<string, unknown>;
      const confirmed = Array.isArray(input.confirmed_slots) ? (input.confirmed_slots as unknown[]).map(String) : [];
      if (!sp) {
        if (Object.keys(slots).length || confirmed.length) return fail('Set the intent first: update_slots(intent=…).');
      } else {
        for (const [k, raw] of Object.entries(slots)) {
          const spec = sp.slots.find((x) => x.name === k);
          if (!spec) { rejected[k] = 'not a field for this intent'; continue; }
          const val = validateSlot(spec.validator, String(raw), d.ctx.clock.todayIso);
          if (!val) {
            s.slotFailures[k] = (s.slotFailures[k] ?? 0) + 1;
            rejected[k] = `invalid ${spec.validator} (attempt ${s.slotFailures[k]})`;
            continue;
          }
          const prev = s.slots[k];
          const same = prev?.value === val;
          s.slots[k] = { value: val, confirmed: same ? prev.confirmed : !spec.needsConfirm, source: 'caller', setAtTurn: same ? prev.setAtTurn : s.totalTurns };
          delete s.slotFailures[k];
          accepted.push(k);
        }
        for (const k of confirmed) {
          const cur = s.slots[k];
          if (!cur) { rejected[k] = 'no value recorded yet'; continue; }
          // Anti-hallucination guard: a value can only be confirmed on a LATER caller turn than the one
          // that set it — i.e. after the agent actually read it back and the caller answered.
          if (cur.setAtTurn >= s.totalTurns) { rejected[k] = 'read it back first and wait for the caller to answer in their next turn'; continue; }
          cur.confirmed = true;
          accepted.push(k);
        }
      }
      const moved = autoAdvance(s, d.intents);
      return ok({ accepted, rejected, moved, ...snapshot(s, d.intents) }, Object.keys(rejected).length);
    }

    case 'advance_state': {
      const to = String(input.to) as CallState;
      if (!MANUAL[s.state].includes(to)) {
        return fail(`${s.state} → ${to} is not allowed. Manual moves from ${s.state}: ${MANUAL[s.state].join(', ') || 'none'}. Normal progress is automatic.`);
      }
      if (s.state === 'CLOSING' && to === 'DATA_COLLECTION' && !s.intentFresh) {
        return fail('Set the new request first: update_slots(intent=…), then advance_state.');
      }
      go(s, to, 'model');
      const moved = autoAdvance(s, d.intents);
      return ok({ moved, ...snapshot(s, d.intents) });
    }

    case 'perform_action': {
      const sp = specOf(s, d.intents);
      if (s.state !== 'ACTION' || !sp) return fail(`perform_action is only valid in ACTION (current: ${s.state}).`);
      if (!sp.action) return fail('This intent has no action. Answer from business knowledge, then advance_state(CLOSING).');
      if (input.action !== sp.action) return fail(`The action for this intent is "${sp.action}".`);
      const slots = Object.fromEntries(Object.entries(s.slots).map(([k, v]) => [k, v.value]));
      const key = `${d.ctx.callId}:${sp.action}:${fnv(JSON.stringify(slots))}`;
      const res = s.actionCache[key] ?? (await d.runAction(sp.action, slots, key));
      if (res.ok) s.actionCache[key] = res;
      s.actionResult = res;
      const moved = res.ok ? autoAdvance(s, d.intents) : [];
      return res.ok
        ? ok({ detail: res.detail, moved, ...snapshot(s, d.intents) })
        : fail('Action failed.', { detail: res.detail, next: 'Explain in one short sentence, offer at most two alternatives or a human callback.' });
    }

    case 'transfer_to_human': {
      if (!d.canTransfer()) return fail('No human is available right now.', { next: 'Offer to register a callback request (intent callback_request).' });
      markHandoff(s, String(input.reason ?? 'unspecified').slice(0, 200));
      return ok({ note: 'Handoff started. Your short transfer line must already be in this response.' });
    }

    case 'end_call': {
      if (s.state !== 'CLOSING') return fail(`end_call is only valid from CLOSING (current: ${s.state}). Use advance_state(CLOSING) first.`);
      markEnd(s, String(input.reason ?? 'done').slice(0, 200));
      return ok({ note: 'Call will end after your goodbye finishes playing.' });
    }

    default:
      return fail(`Unknown tool "${name}".`);
  }
}
