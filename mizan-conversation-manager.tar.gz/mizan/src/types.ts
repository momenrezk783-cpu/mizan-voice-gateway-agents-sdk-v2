import type { CallSession } from './call-session';

export interface Env {
  DB: D1Database;
  CALL_SESSION: DurableObjectNamespace<CallSession>;
  EVAL_QUEUE: Queue<EvalJob>;
  ANTHROPIC_API_KEY: string;
  WEBHOOK_SECRET: string; // telephony → Worker (HMAC of raw body)
  STREAM_TOKEN_SECRET: string; // signs the per-call WebSocket token
  CONVERSATION_MODEL: string;
  EVALUATOR_MODEL: string;
  PROMPT_VERSION: string;
  HOLDOUT_RATE: string; // "0.1" → 10% of calls run WITHOUT learnings (control group)
}

export type CallState = 'GREETING' | 'DATA_COLLECTION' | 'ACTION' | 'CLOSING' | 'ENDED';
export type CallerType = 'new_lead' | 'returning_customer' | 'unknown';
export type Gender = 'male' | 'female' | 'unknown';
export type Arm = 'treated' | 'holdout' | 'disabled';
export type EndReason = 'agent_end' | 'caller_hangup' | 'handoff' | 'idle_timeout' | 'max_duration' | 'error';

export interface EvalJob {
  callId: string;
  tenantId: string;
}

// ---- Intent / slot catalogue (JSON-serialisable so tenants can configure it in D1) ----------
export type ValidatorName = 'text' | 'phone_eg' | 'email' | 'date_iso' | 'time_hhmm';

export interface SlotSpec {
  name: string;
  label: string; // shown to the model in <live_state>
  required: boolean;
  validator: ValidatorName;
  needsConfirm?: boolean; // must be read back once and confirmed by the caller
  prefill?: 'caller_id' | 'crm_name' | 'crm_email';
  carryOver?: boolean; // survives an intent change within the same call
}

export interface IntentSpec {
  id: string;
  label: string;
  action: string | null; // null → answer-only intent (no side effect)
  slots: SlotSpec[];
}

export interface TenantConfig {
  businessName: string;
  agentName: string;
  agentGender: 'male' | 'female';
  timezone?: string; // default Africa/Cairo
  businessHours?: string;
  knowledge?: string; // FAQ / services text injected as <business_knowledge>
  handoffNumber?: string;
  actionWebhookUrl?: string; // https only — validate when the tenant saves it (SSRF)
  actionWebhookSecret?: string;
  intents?: IntentSpec[];
}

// ---- Per-call context: this is how "new lead vs returning customer" reaches the agent -------
export interface CallContext {
  callId: string;
  tenantId: string;
  direction: 'inbound' | 'outbound';
  callerPhone: string | null; // E.164, null if withheld
  callerType: CallerType;
  caller: {
    firstName: string | null;
    gender: Gender;
    lastSummary: string | null;
    lastCallAt: number | null;
  };
  business: {
    name: string;
    agentName: string;
    agentGender: 'male' | 'female';
    hours: string | null;
    knowledge: string | null;
    handoffNumber: string | null;
  };
  clock: { todayIso: string; weekday: string; localTime: string; timezone: string; greetingWord: string };
}

export interface Learning {
  id: string;
  scope: 'global' | 'tenant';
  key: string;
  category: string;
  applies_state: CallState | null;
  applies_caller: CallerType | null;
  instruction: string;
  example_ar: string | null;
  confidence: number;
  support_count: number;
}

export interface TranscriptLine {
  role: 'caller' | 'agent';
  text: string;
  state: CallState;
  ts: number;
  interrupted?: boolean;
}

export interface CallMetrics {
  honorificHits: number; // output-guard hits (should trend to ~0)
  msaHits: number; // MSA markers seen in agent speech
  llmErrors: number;
  llmConsecutive: number;
  slotRejections: number;
  bargeIns: number;
}
