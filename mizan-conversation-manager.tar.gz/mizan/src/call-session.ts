// CallSession Durable Object — one instance per active call.
//
// Lifecycle:
//   1. The telephony webhook (handled by src/index.ts) creates/retrieves the DO by callId.
//   2. The DO receives:
//      • POST /init       — first message from the Worker; seeds state from D1
//      • WebSocket /ws    — real-time bidirectional channel with the telephony bridge
//   3. Each caller utterance comes in over WS → goes to processUtterance() → LLM → TTS chunks
//      streamed back over WS.
//   4. When the call ends, the DO enqueues an EvalJob and hibernates.
//
// Everything state-sensitive (session, transcript, metrics) lives INSIDE the DO.
// The DO survives Worker restarts and cross-DC routing because CF pins the DO to one city.

import { DurableObject } from 'cloudflare:workers';
import { buildTools, executeTool, markEnd, markHandoff, newSession, renderLiveState, DEFAULT_INTENTS } from './manager';
import { buildSystemBlocks } from './prompt';
import { streamCompletion } from './llm';
import { sanitizeForSpeech, detectNonEgyptian, SpeechChunker } from './guard';
import { insertCallRecord, loadLearnings, loadTenantConfig, closeCallRecord, saveTranscript } from './db';
import type { Env, CallContext, CallMetrics, TranscriptLine, IntentSpec } from './types';
import type { Session } from './manager';
import type { Block, Msg, ToolUseBlock } from './llm';

// WebSocket message shapes (telephony bridge → DO)
interface WsUtterance { type: 'utterance'; text: string; final: boolean; interrupted?: boolean }
interface WsEvent     { type: 'event'; name: string }
type WsIn = WsUtterance | WsEvent;

// WebSocket message shapes (DO → telephony bridge)
interface WsSpeech  { type: 'speech'; text: string; final: boolean }
interface WsAction  { type: 'action'; action: string; params: Record<string, string> }
interface WsControl { type: 'control'; command: 'end_call' | 'transfer'; params?: Record<string, string> }
type WsOut = WsSpeech | WsAction | WsControl;

const send = (ws: WebSocket, msg: WsOut) => ws.send(JSON.stringify(msg));
const MAX_HISTORY = 60;   // LLM context: last N messages (oldest dropped to stay within token budget)
const TTFB_MS    = 3_500; // abort LLM if no first token within 3.5 s
const LLM_MAX_MS = 30_000;
const MAX_TOOL_ROUNDS = 6; // per utterance — prevents infinite tool loops

export class CallSession extends DurableObject<Env> {
  #ctx!: CallContext;
  #session!: Session;
  #history: Msg[] = [];
  #transcript: TranscriptLine[] = [];
  #metrics: CallMetrics = { honorificHits: 0, msaHits: 0, llmErrors: 0, llmConsecutive: 0, slotRejections: 0, bargeIns: 0 };
  #learnings: Awaited<ReturnType<typeof loadLearnings>> = [];
  #intents: IntentSpec[] = DEFAULT_INTENTS;
  #startedAt = 0;
  #arm: 'treated' | 'holdout' | 'disabled' = 'treated';
  #ready = false;
  #ws: WebSocket | null = null;

  // ── Init ───────────────────────────────────────────────────────────────────

  async fetch(request: Request): Promise<Response> {
    const url = new URL(request.url);

    if (url.pathname === '/init') {
      const body = await request.json<{ ctx: CallContext; arm: 'treated' | 'holdout' | 'disabled' }>();
      await this.#init(body.ctx, body.arm);
      return new Response('ok');
    }

    if (url.pathname === '/ws') {
      const token = url.searchParams.get('token');
      if (!this.#verifyWsToken(token, url.searchParams.get('callId') ?? ''))
        return new Response('Unauthorized', { status: 401 });
      const { 0: client, 1: server } = new WebSocketPair();
      this.ctx.acceptWebSocket(server);
      this.#ws = server;
      return new Response(null, { status: 101, webSocket: client });
    }

    return new Response('Not found', { status: 404 });
  }

  async webSocketMessage(ws: WebSocket, raw: string | ArrayBuffer): Promise<void> {
    if (typeof raw !== 'string') return;
    let msg: WsIn;
    try { msg = JSON.parse(raw); } catch { return; }
    if (!this.#ready) { ws.send(JSON.stringify({ type: 'error', error: 'not_ready' })); return; }

    if (msg.type === 'event') {
      await this.#handleSystemEvent(ws, msg.name);
      return;
    }
    if (msg.type === 'utterance' && msg.final) {
      if (msg.interrupted) this.#metrics.bargeIns++;
      await this.#processUtterance(ws, msg.text, msg.interrupted ?? false);
    }
  }

  async webSocketClose(ws: WebSocket, code: number): Promise<void> {
    await this.#endCall('caller_hangup');
  }

  // ── Private ────────────────────────────────────────────────────────────────

  async #init(ctx: CallContext, arm: 'treated' | 'holdout' | 'disabled'): Promise<void> {
    this.#ctx = ctx;
    this.#arm = arm;
    this.#session = newSession();
    this.#startedAt = Date.now();

    // Load tenant config (may override default intents)
    const config = await loadTenantConfig(this.env.DB, ctx.tenantId);
    if (config?.intents?.length) this.#intents = config.intents;

    // Load learnings (skipped for holdout arm = control group, to measure improvement delta)
    if (arm === 'treated') {
      this.#learnings = await loadLearnings(this.env.DB, ctx.tenantId, ctx.callerType);
    }

    await insertCallRecord(this.env.DB, {
      callId: ctx.callId, tenantId: ctx.tenantId, callerPhone: ctx.callerPhone,
      direction: ctx.direction, arm, promptVersion: this.env.PROMPT_VERSION,
    });

    this.#ready = true;
  }

  async #handleSystemEvent(ws: WebSocket, name: string): Promise<void> {
    if (name === 'call_connected') {
      await this.#processUtterance(ws, `[SYSTEM_EVENT: call_connected]`, false);
    } else if (name.startsWith('caller_silent_')) {
      await this.#processUtterance(ws, `[SYSTEM_EVENT: ${name}]`, false);
    }
  }

  async #processUtterance(ws: WebSocket, text: string, interrupted: boolean): Promise<void> {
    const isSystem = text.startsWith('[SYSTEM_EVENT:');
    if (!isSystem) {
      this.#session.totalTurns++;
      this.#session.turnsInState++;
      this.#transcript.push({ role: 'caller', text, state: this.#session.state, ts: Date.now(), interrupted });
      this.#pushHistory({ role: 'user', content: text });
    }

    // Build system blocks (static cached | per-call cached | live state hot)
    const liveState = renderLiveState(this.#session, this.#ctx, this.#intents);
    const system = buildSystemBlocks(this.#ctx, this.#learnings, liveState);
    const tools = buildTools(this.#intents);

    // ── Multi-round tool loop ────────────────────────────────────────────────
    for (let round = 0; round < MAX_TOOL_ROUNDS; round++) {
      const agentText: string[] = [];
      const toolCalls: ToolUseBlock[] = [];

      // Stream with TTFB guard
      const ctrl = new AbortController();
      const ttfb = setTimeout(() => ctrl.abort('ttfb'), TTFB_MS);
      const total = setTimeout(() => ctrl.abort('total'), LLM_MAX_MS);

      const chunker = new SpeechChunker((chunk) => {
        const { text: clean, violations } = sanitizeForSpeech(chunk);
        if (violations.length) this.#metrics.honorificHits += violations.length;
        const msa = detectNonEgyptian(clean);
        if (msa.length) this.#metrics.msaHits += msa.length;
        if (clean) send(ws, { type: 'speech', text: clean, final: false });
      });

      let llmFailed = false;
      try {
        const result = await streamCompletion({
          apiKey: this.env.ANTHROPIC_API_KEY,
          model: this.env.CONVERSATION_MODEL,
          system,
          messages: this.#history,
          tools,
          maxTokens: 512,
          signal: ctrl.signal,
          onStart: () => clearTimeout(ttfb),
          onText: (delta) => { agentText.push(delta); chunker.push(delta); },
        });
        chunker.flush();
        clearTimeout(total);
        this.#metrics.llmConsecutive = 0;

        for (const b of result.content) {
          if (b.type === 'tool_use') toolCalls.push(b);
        }
      } catch (err) {
        clearTimeout(ttfb);
        clearTimeout(total);
        chunker.discard();
        this.#metrics.llmErrors++;
        this.#metrics.llmConsecutive++;
        llmFailed = true;
        console.error('[session] LLM error', err);

        if (this.#metrics.llmConsecutive >= 3) {
          // 3 consecutive LLM failures → failsafe handoff
          send(ws, { type: 'speech', text: 'معلش، في مشكلة تقنية دلوقتي. ثواني أحوّلك لحد من الفريق.', final: true });
          send(ws, { type: 'control', command: 'transfer', params: { reason: 'consecutive_llm_errors' } });
          markHandoff(this.#session, 'consecutive_llm_errors');
          await this.#endCall('error');
          return;
        }
        // Single failure: polite retry prompt
        const retry = this.#metrics.llmConsecutive === 1 ? 'معلش، مسمعتش كويس. ممكن تعيد؟' : 'معلش، في مشكلة بسيطة. ثواني.';
        send(ws, { type: 'speech', text: retry, final: true });
        return;
      }

      const fullAgentText = agentText.join('');

      // Record agent turn in history + transcript
      const contentBlocks: Block[] = [];
      if (fullAgentText) contentBlocks.push({ type: 'text', text: fullAgentText });
      for (const tc of toolCalls) contentBlocks.push(tc);
      if (contentBlocks.length) this.#pushHistory({ role: 'assistant', content: contentBlocks });

      if (fullAgentText && !isSystem) {
        this.#transcript.push({ role: 'agent', text: fullAgentText, state: this.#session.state, ts: Date.now() });
      }

      if (!toolCalls.length) {
        // No tools called → turn is done
        send(ws, { type: 'speech', text: '', final: true });
        break;
      }

      // Execute tools, build tool_result blocks for the next round
      const resultBlocks: Block[] = [];
      for (const tc of toolCalls) {
        const outcome = await executeTool(
          {
            ctx: this.#ctx,
            intents: this.#intents,
            runAction: (action, slots, key) => this.#dispatchAction(action, slots, key),
            canTransfer: () => !!this.env.CALL_SESSION,
          },
          this.#session,
          tc.name,
          tc.input,
        );
        if (outcome.rejected) this.#metrics.slotRejections += outcome.rejected;
        resultBlocks.push({ type: 'tool_result', tool_use_id: tc.id, content: outcome.content, is_error: outcome.isError });
      }
      this.#pushHistory({ role: 'user', content: resultBlocks });

      // Handle terminal states triggered by tools
      if (this.#session.state === 'ENDED') {
        send(ws, { type: 'speech', text: '', final: true });
        if (this.#session.handoff) {
          send(ws, { type: 'control', command: 'transfer', params: { reason: this.#session.handoff.reason } });
        } else {
          send(ws, { type: 'control', command: 'end_call' });
        }
        await this.#endCall(this.#session.handoff ? 'handoff' : (this.#session.endRequest?.reason ?? 'agent_end'));
        return;
      }
    }
  }

  // ── Action webhook ─────────────────────────────────────────────────────────

  async #dispatchAction(action: string, slots: Record<string, string>, idempotencyKey: string): Promise<{ ok: boolean; detail: string }> {
    const config = await loadTenantConfig(this.env.DB, this.#ctx.tenantId);
    const webhookUrl = config?.actionWebhookUrl;
    if (!webhookUrl) return { ok: false, detail: 'No action webhook configured for this tenant.' };

    try {
      new URL(webhookUrl); // validates; rejects relative URLs and non-URL strings
      if (!webhookUrl.startsWith('https://')) throw new Error('webhook must be HTTPS');
    } catch (e) {
      console.error('[session] invalid actionWebhookUrl', e);
      return { ok: false, detail: 'Webhook URL misconfigured.' };
    }

    const body = JSON.stringify({ callId: this.#ctx.callId, action, slots, idempotencyKey });
    const sig = await this.#hmacSign(body, config.actionWebhookSecret ?? this.env.WEBHOOK_SECRET);

    let res: Response;
    try {
      res = await fetch(webhookUrl, {
        method: 'POST',
        headers: { 'content-type': 'application/json', 'x-mizan-signature': sig, 'x-idempotency-key': idempotencyKey },
        body,
        signal: AbortSignal.timeout(8_000),
      });
    } catch (err) {
      return { ok: false, detail: 'Could not reach the action endpoint. Network error.' };
    }

    if (res.ok) {
      let detail = '';
      try { const j = await res.json<{ message?: string }>(); detail = j.message ?? 'Done.'; } catch { detail = 'Done.'; }
      return { ok: true, detail };
    }
    let errMsg = 'The action endpoint returned an error.';
    try { const j = await res.json<{ error?: string }>(); if (j.error) errMsg = j.error.slice(0, 200); } catch { /* ignore */ }
    return { ok: false, detail: errMsg };
  }

  // ── Call teardown ──────────────────────────────────────────────────────────

  async #endCall(reason: string): Promise<void> {
    const endedAt = Date.now();
    await saveTranscript(this.env.DB, this.#ctx.callId, this.#transcript);
    await closeCallRecord(this.env.DB, this.#ctx.callId, {
      endReason: reason,
      durationSec: Math.round((endedAt - this.#startedAt) / 1000),
      totalTurns: this.#session.totalTurns,
      intentResolved: this.#session.actionResult?.ok ?? false,
      handedOff: !!this.#session.handoff,
      honorificHits: this.#metrics.honorificHits,
      msaHits: this.#metrics.msaHits,
      llmErrors: this.#metrics.llmErrors,
    });
    await this.env.EVAL_QUEUE.send({
      callId: this.#ctx.callId,
      tenantId: this.#ctx.tenantId,
    });
  }

  // ── Helpers ────────────────────────────────────────────────────────────────

  #pushHistory(msg: Msg): void {
    this.#history.push(msg);
    if (this.#history.length > MAX_HISTORY) this.#history.splice(0, this.#history.length - MAX_HISTORY);
  }

  #verifyWsToken(token: string | null, callId: string): boolean {
    if (!token) return false;
    // In production: verify a short-lived HMAC token signed with STREAM_TOKEN_SECRET
    // Here we do a constant-time compare to avoid timing attacks
    const expected = `${callId}:${this.env.STREAM_TOKEN_SECRET}`;
    if (token.length !== expected.length) return false;
    let diff = 0;
    for (let i = 0; i < token.length; i++) diff |= token.charCodeAt(i) ^ expected.charCodeAt(i);
    return diff === 0;
  }

  async #hmacSign(body: string, secret: string): Promise<string> {
    const key = await crypto.subtle.importKey('raw', new TextEncoder().encode(secret), { name: 'HMAC', hash: 'SHA-256' }, false, ['sign']);
    const sig = await crypto.subtle.sign('HMAC', key, new TextEncoder().encode(body));
    return Array.from(new Uint8Array(sig)).map((b) => b.toString(16).padStart(2, '0')).join('');
  }
}
