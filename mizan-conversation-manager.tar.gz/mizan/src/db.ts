// All D1 access lives here. The rest of the codebase never touches env.DB directly.
// Queries are parameterised; no string interpolation of user/external data.

import type { D1Database } from '@cloudflare/workers-types';
import type { CallContext, CallerType, Gender, Learning, TenantConfig, TranscriptLine } from './types';

// ─── Schema version ───────────────────────────────────────────────────────────
// Migrations live in /migrations/*.sql (applied via wrangler d1 migrations apply).
// This file only reads/writes; it never DDLs at runtime.

// ─── Learnings ────────────────────────────────────────────────────────────────

/**
 * Load active learnings for a call.
 *
 * Strategy:
 *   1. Global learnings (scope = 'global')   — shared across all tenants
 *   2. Tenant learnings (scope = 'tenant')   — override / complement globals
 *   3. Never return learnings that have been soft-deleted or whose confidence < threshold
 *   4. Respect applies_caller filter: null = any, else only that CallerType
 *   5. Order: applies_state ASC NULLS LAST (ANY-state rules last → model reads state rules first)
 *
 * Returned list is already de-duped: if a tenant learning shares the same `key` as a global one,
 * the tenant version wins (higher specificity).
 */
export async function loadLearnings(
  db: D1Database,
  tenantId: string,
  callerType: CallerType,
  minConfidence = 0.6,
  maxItems = 24,
): Promise<Learning[]> {
  const { results } = await db
    .prepare(
      `SELECT l.id, l.scope, l.key, l.category, l.applies_state, l.applies_caller,
              l.instruction, l.example_ar, l.confidence, l.support_count
       FROM   learnings l
       WHERE  l.deleted_at IS NULL
         AND  l.confidence >= ?1
         AND  (l.scope = 'global' OR (l.scope = 'tenant' AND l.tenant_id = ?2))
         AND  (l.applies_caller IS NULL OR l.applies_caller = ?3)
       ORDER BY
              -- tenant-specific before global
              CASE l.scope WHEN 'tenant' THEN 0 ELSE 1 END,
              -- state-specific before ANY
              l.applies_state NULLS LAST,
              l.confidence DESC
       LIMIT  ?4`,
    )
    .bind(minConfidence, tenantId, callerType, maxItems * 2) // fetch extra to de-dup
    .all<Learning>();

  // De-dup by key: tenant wins over global (already first in ORDER BY, so just take first seen)
  const seen = new Set<string>();
  const deduped: Learning[] = [];
  for (const r of results) {
    if (!seen.has(r.key)) { seen.add(r.key); deduped.push(r); }
    if (deduped.length >= maxItems) break;
  }
  return deduped;
}

/**
 * Upsert a learning produced by the evaluator.
 * Uses a UNIQUE constraint on (tenant_id, scope, key) in the schema.
 * On conflict: bump support_count, recalculate confidence, update instruction if improved.
 */
export async function upsertLearning(
  db: D1Database,
  l: Omit<Learning, 'id' | 'support_count'> & { tenantId: string; newConfidence: number },
): Promise<void> {
  const id = crypto.randomUUID();
  await db
    .prepare(
      `INSERT INTO learnings
         (id, tenant_id, scope, key, category, applies_state, applies_caller,
          instruction, example_ar, confidence, support_count, created_at, updated_at)
       VALUES (?1,?2,?3,?4,?5,?6,?7,?8,?9,?10,1,unixepoch(),unixepoch())
       ON CONFLICT(tenant_id, scope, key) DO UPDATE SET
         support_count = support_count + 1,
         confidence    = MAX(confidence, excluded.confidence),
         instruction   = CASE WHEN excluded.confidence > confidence THEN excluded.instruction ELSE instruction END,
         example_ar    = CASE WHEN excluded.confidence > confidence THEN excluded.example_ar  ELSE example_ar  END,
         updated_at    = unixepoch()`,
    )
    .bind(id, l.tenantId, l.scope, l.key, l.category, l.applies_state ?? null, l.applies_caller ?? null, l.instruction, l.example_ar ?? null, l.newConfidence)
    .run();
}

/** Soft-delete a learning (e.g. a supervisor marks it as wrong). */
export async function deleteLearning(db: D1Database, id: string): Promise<void> {
  await db.prepare(`UPDATE learnings SET deleted_at = unixepoch() WHERE id = ?1`).bind(id).run();
}

// ─── Tenant config ─────────────────────────────────────────────────────────────

export async function loadTenantConfig(db: D1Database, tenantId: string): Promise<TenantConfig | null> {
  const row = await db
    .prepare(`SELECT config_json FROM tenants WHERE id = ?1 AND active = 1`)
    .bind(tenantId)
    .first<{ config_json: string }>();
  if (!row) return null;
  try { return JSON.parse(row.config_json) as TenantConfig; } catch { return null; }
}

// ─── CRM / caller lookup ───────────────────────────────────────────────────────

interface CrmRow {
  first_name: string | null;
  gender: Gender;
  last_call_at: number | null;
  last_summary: string | null;
  email: string | null;
}

export async function lookupCaller(
  db: D1Database,
  tenantId: string,
  phone: string,
): Promise<{ callerType: CallerType; crm: CrmRow } | null> {
  const row = await db
    .prepare(
      `SELECT first_name, gender, email,
              last_call_at, last_summary
       FROM   crm_contacts
       WHERE  tenant_id = ?1 AND phone = ?2 AND deleted_at IS NULL`,
    )
    .bind(tenantId, phone)
    .first<CrmRow>();
  if (!row) return null;
  return { callerType: 'returning_customer', crm: row };
}

export async function upsertCrmContact(
  db: D1Database,
  tenantId: string,
  phone: string,
  update: { firstName?: string; gender?: Gender; email?: string; lastSummary?: string; lastCallAt?: number },
): Promise<void> {
  const id = crypto.randomUUID();
  await db
    .prepare(
      `INSERT INTO crm_contacts (id, tenant_id, phone, first_name, gender, email, last_call_at, last_summary, created_at, updated_at)
       VALUES (?1,?2,?3,?4,?5,?6,?7,?8,unixepoch(),unixepoch())
       ON CONFLICT(tenant_id, phone) DO UPDATE SET
         first_name   = COALESCE(excluded.first_name,   first_name),
         gender       = CASE WHEN excluded.gender != 'unknown' THEN excluded.gender ELSE gender END,
         email        = COALESCE(excluded.email,        email),
         last_call_at = COALESCE(excluded.last_call_at, last_call_at),
         last_summary = COALESCE(excluded.last_summary, last_summary),
         updated_at   = unixepoch()`,
    )
    .bind(
      id, tenantId, phone,
      update.firstName ?? null,
      update.gender ?? 'unknown',
      update.email ?? null,
      update.lastCallAt ?? null,
      update.lastSummary ?? null,
    )
    .run();
}

// ─── Call records ──────────────────────────────────────────────────────────────

export async function insertCallRecord(
  db: D1Database,
  r: { callId: string; tenantId: string; callerPhone: string | null; direction: string; arm: string; promptVersion: string },
): Promise<void> {
  await db
    .prepare(
      `INSERT OR IGNORE INTO calls
         (id, tenant_id, caller_phone, direction, arm, prompt_version, started_at)
       VALUES (?1,?2,?3,?4,?5,?6,unixepoch())`,
    )
    .bind(r.callId, r.tenantId, r.callerPhone, r.direction, r.arm, r.promptVersion)
    .run();
}

export async function closeCallRecord(
  db: D1Database,
  callId: string,
  r: {
    endReason: string;
    durationSec: number;
    totalTurns: number;
    intentResolved: boolean;
    handedOff: boolean;
    honorificHits: number;
    msaHits: number;
    llmErrors: number;
  },
): Promise<void> {
  await db
    .prepare(
      `UPDATE calls SET
         ended_at         = unixepoch(),
         end_reason       = ?2,
         duration_sec     = ?3,
         total_turns      = ?4,
         intent_resolved  = ?5,
         handed_off       = ?6,
         honorific_hits   = ?7,
         msa_hits         = ?8,
         llm_errors       = ?9
       WHERE id = ?1`,
    )
    .bind(callId, r.endReason, r.durationSec, r.totalTurns, r.intentResolved ? 1 : 0, r.handedOff ? 1 : 0, r.honorificHits, r.msaHits, r.llmErrors)
    .run();
}

export async function saveTranscript(
  db: D1Database,
  callId: string,
  lines: TranscriptLine[],
): Promise<void> {
  if (!lines.length) return;
  // Batch insert; D1 supports up to 100 bound params per statement
  const CHUNK = 20; // 7 params × 20 = 140 — safe
  for (let i = 0; i < lines.length; i += CHUNK) {
    const slice = lines.slice(i, i + CHUNK);
    const ph = slice.map((_, j) => `(?${j * 7 + 1},?${j * 7 + 2},?${j * 7 + 3},?${j * 7 + 4},?${j * 7 + 5},?${j * 7 + 6},?${j * 7 + 7})`).join(',');
    const vals = slice.flatMap((l, j) => [crypto.randomUUID(), callId, l.role, l.text, l.state, l.ts, l.interrupted ? 1 : 0]);
    await db.prepare(`INSERT INTO transcript_lines (id,call_id,role,text,state,ts,interrupted) VALUES ${ph}`).bind(...vals).run();
  }
}

export async function loadTranscript(db: D1Database, callId: string): Promise<TranscriptLine[]> {
  const { results } = await db
    .prepare(`SELECT role,text,state,ts,interrupted FROM transcript_lines WHERE call_id=?1 ORDER BY ts`)
    .bind(callId)
    .all<TranscriptLine & { interrupted: number }>();
  return results.map((r) => ({ ...r, interrupted: !!r.interrupted }));
}
