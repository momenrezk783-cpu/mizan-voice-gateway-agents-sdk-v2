import MASTER from './prompts/master.ar.md';
import type { CallContext, Learning } from './types';
import type { SystemBlock } from './llm';

// The master prompt is split at <call_context>:
//   block 1  STATIC   — tenant-agnostic rules/persona/examples → identical across ALL calls → provider-cached
//   block 2  PER-CALL — call context + learnings. Frozen at call start → cached from turn 2 onward
//   block 3  LIVE     — state/slots, changes every hop → never cached
const SPLIT = '<call_context>';
const cut = MASTER.indexOf(SPLIT);
if (cut < 0) throw new Error('master prompt: <call_context> marker missing');
const STATIC_PART = MASTER.slice(0, cut).trimEnd();
const PER_CALL_TEMPLATE = MASTER.slice(cut);

// Anything that originates from callers/CRM/evaluator is DATA: strip angle brackets (no tag spoofing),
// flatten whitespace, cap length. This is the prompt-injection chokepoint for stored text.
const clean = (s: string | null | undefined, max: number) => (s ?? '').replace(/[<>]/g, '').replace(/\s+/g, ' ').trim().slice(0, max);
const cleanBlock = (s: string | null | undefined, max: number) => (s ?? '').replace(/[<>]/g, '').trim().slice(0, max);

export function renderCallContext(c: CallContext): string {
  const lines = [
    `business_name: ${clean(c.business.name, 80)}`,
    `business_hours: ${clean(c.business.hours, 200) || 'not provided'}`,
    `agent_name: ${clean(c.business.agentName, 40)}`,
    `agent_gender: ${c.business.agentGender}`,
    `direction: ${c.direction}`,
    `caller_type: ${c.callerType}`,
    `caller_first_name: ${clean(c.caller.firstName, 40) || 'unknown'}`,
    `caller_gender: ${c.caller.gender}`,
    `last_interaction_summary: ${clean(c.caller.lastSummary, 300) || 'none'}`,
    `greeting_word_for_now: ${c.clock.greetingWord}`,
    '<business_knowledge>',
    cleanBlock(c.business.knowledge, 4000) || 'No knowledge base provided: do not state prices, policies or availability.',
    '</business_knowledge>',
  ];
  return lines.join('\n');
}

export function renderLearnings(ls: Learning[]): string {
  if (!ls.length) return '(none yet)';
  const order = ['ANY', 'GREETING', 'DATA_COLLECTION', 'ACTION', 'CLOSING'];
  const groups = new Map<string, Learning[]>();
  for (const l of ls) {
    const g = l.applies_state ?? 'ANY';
    groups.set(g, [...(groups.get(g) ?? []), l]);
  }
  const out: string[] = [];
  for (const g of order) {
    const items = groups.get(g);
    if (!items?.length) continue;
    out.push(`[${g === 'ANY' ? 'ALL STATES' : g}]`);
    for (const l of items) {
      out.push(`- ${clean(l.instruction, 260)}${l.example_ar ? ` (مثال: ${clean(l.example_ar, 140)})` : ''}`);
    }
  }
  return out.join('\n');
}

export function buildSystemBlocks(ctx: CallContext, learnings: Learning[], liveState: string): SystemBlock[] {
  const perCall = PER_CALL_TEMPLATE
    .replace('{{CALL_CONTEXT}}', () => renderCallContext(ctx))
    .replace('{{LEARNINGS}}', () => renderLearnings(learnings));
  return [
    { type: 'text', text: STATIC_PART, cache_control: { type: 'ephemeral' } },
    { type: 'text', text: perCall, cache_control: { type: 'ephemeral' } },
    { type: 'text', text: liveState },
  ];
}
