// Post-call evaluator — runs asynchronously on the EVAL_QUEUE after every call.
//
// What it does:
//   1. Loads the transcript + call metadata from D1
//   2. Calls the LLM with a forced-tool schema (callForcedTool) → structured evaluation
//   3. Validates and sanitizes each extracted learning against hard rules
//   4. Upserts into D1 (learnings table). Support_count + confidence accumulate over time.
//   5. Updates the CRM contact with any name/gender/email inferred from the conversation.
//   6. Writes a compact summary back to the call record (last_summary for next call context).
//
// SAFETY CONTRACT: learnings can only influence HOW the agent phrases things and in what order
// it asks for data. They cannot change persona, language rules, state machine guards, or
// security/honesty rules (see <learned_adaptations_rules> in the master prompt, and the
// validateLearning() function below which enforces this programmatically).

import { callForcedTool } from './llm';
import { loadTranscript, upsertLearning, upsertCrmContact, saveTranscript } from './db';
import { containsBannedAddress } from './guard';
import type { CallState, CallerType, Gender, Learning, TranscriptLine } from './types';

// ─── Evaluator input (passed via Queue message) ───────────────────────────────

export interface EvalInput {
  callId: string;
  tenantId: string;
  callerPhone: string | null;
  callerType: CallerType;
  arm: 'treated' | 'holdout' | 'disabled'; // used to track A/B; holdout calls also get evaluated but their learnings feed the future pool differently
  startedAt: number;
  endedAt: number;
  endReason: string;
  totalTurns: number;
  intentId: string | null;
  intentResolved: boolean;
  handedOff: boolean;
  honorificHits: number; // guard violations
  msaHits: number;
  llmErrors: number;
  finalSlots: Record<string, { value: string; confirmed: boolean }>;
}

// ─── LLM evaluation schema ────────────────────────────────────────────────────

const EVAL_TOOL = {
  name: 'submit_call_evaluation',
  description: 'Submit the structured evaluation of this call.',
  input_schema: {
    type: 'object' as const,
    properties: {
      overall_quality: { type: 'number', description: 'Float 0–1. 1 = perfect call.' },
      intent_clarity: { type: 'number', description: 'How quickly the agent understood the intent (0–1).' },
      data_collection_efficiency: { type: 'number', description: 'How smoothly data was collected without redundant questions (0–1).' },
      persona_adherence: { type: 'number', description: 'Egyptian Arabic, no honorifics, correct register (0–1).' },
      caller_friction_points: {
        type: 'array',
        description: 'Each event where the caller showed frustration, confusion or disengagement.',
        items: {
          type: 'object',
          properties: {
            turn: { type: 'number' },
            quote_ar: { type: 'string', description: 'Short excerpt from the agent turn that caused friction (agent words, not caller words).' },
            reason: { type: 'string' },
          },
          required: ['turn', 'reason'],
        },
      },
      learnings: {
        type: 'array',
        description: 'Each concrete, actionable instruction for the agent to change its behaviour on future calls. Each must be derived from something that actually happened in this transcript.',
        items: {
          type: 'object',
          properties: {
            key: { type: 'string', description: 'Stable slug, e.g. "phone_collection_strategy". Same key = same learning; upsert + confidence merge.' },
            category: { type: 'string', enum: ['phrasing', 'ordering', 'pacing', 'recovery', 'confirmation', 'intent_detection'] },
            applies_state: { type: 'string', enum: ['GREETING', 'DATA_COLLECTION', 'ACTION', 'CLOSING', null], description: 'null = applies to all states' },
            applies_caller: { type: 'string', enum: ['new_lead', 'returning_customer', null], description: 'null = applies to all caller types' },
            instruction: { type: 'string', description: 'One clear sentence the agent should follow. Egyptian Arabic OK; no honorifics.' },
            example_ar: { type: 'string', description: 'Optional: show the BETTER phrasing in Egyptian Arabic.' },
            confidence: { type: 'number', description: 'Your confidence this learning is correct and generalises (0–1).' },
            scope: { type: 'string', enum: ['global', 'tenant'], description: 'global = likely applies to all tenants. tenant = specific to this business.' },
          },
          required: ['key', 'category', 'instruction', 'confidence', 'scope'],
        },
      },
      inferred_caller_first_name: { type: 'string', description: 'If the caller stated their first name, write it here (Latin or Arabic). Otherwise empty string.' },
      inferred_caller_gender: { type: 'string', enum: ['male', 'female', 'unknown'] },
      inferred_caller_email: { type: 'string', description: 'Email the caller confirmed, or empty string.' },
      call_summary_ar: { type: 'string', description: 'Two sentences max in Egyptian Arabic summarising what was done or what is pending. This will be shown at the NEXT call as last_interaction_summary.' },
    },
    required: ['overall_quality', 'persona_adherence', 'learnings', 'call_summary_ar', 'inferred_caller_gender'],
  },
};

// ─── Safety validator ─────────────────────────────────────────────────────────

interface RawLearning {
  key: string;
  category: string;
  applies_state?: string | null;
  applies_caller?: string | null;
  instruction: string;
  example_ar?: string | null;
  confidence: number;
  scope: 'global' | 'tenant';
}

const FORBIDDEN_INSTRUCTION_PATTERNS = [
  // Block any instruction that tries to override persona rules
  /(?:استخدم|قول|اذكر|استعمل)\s+(?:حضرتك|يا\s*فندم|سيادتك)/iu,
  // Block MSA instructions
  /\b(?:ماذا|لماذا|كيف\s+يمكن|سوف\s+أ|الآن|يسعدني)\b/u,
  // Block instructions that touch security/honesty
  /(?:ادّعي|تظاهر|وهم|اكذب|اخفِ|أخفِ)/iu,
  // Block instructions about price/policy invention
  /(?:اختلق|اخترع|قدّر|افترض)\s+(?:سعر|سياسة|رسوم|تكلفة)/iu,
  // Block meta-instructions that reference the prompt itself
  /(?:هذا\s+البرومبت|النظام\s+البرومبت|تجاهل\s+التعليمات|ignore\s+previous)/iu,
];

function validateLearning(raw: RawLearning): { ok: true; learning: RawLearning } | { ok: false; reason: string } {
  if (!raw.key || !/^[a-z][a-z0-9_]{2,59}$/.test(raw.key))
    return { ok: false, reason: `invalid key "${raw.key}"` };
  if (raw.confidence < 0.5) return { ok: false, reason: 'confidence too low (< 0.5)' };
  if (!raw.instruction || raw.instruction.length < 10 || raw.instruction.length > 300)
    return { ok: false, reason: 'instruction length out of range' };
  if (containsBannedAddress(raw.instruction) || (raw.example_ar && containsBannedAddress(raw.example_ar)))
    return { ok: false, reason: 'instruction or example contains a banned address form' };
  for (const rx of FORBIDDEN_INSTRUCTION_PATTERNS) {
    if (rx.test(raw.instruction) || (raw.example_ar && rx.test(raw.example_ar)))
      return { ok: false, reason: `instruction matches forbidden pattern ${rx}` };
  }
  const VALID_STATES = new Set(['GREETING', 'DATA_COLLECTION', 'ACTION', 'CLOSING', null, undefined]);
  if (!VALID_STATES.has(raw.applies_state as CallState | null | undefined))
    return { ok: false, reason: `unknown state "${raw.applies_state}"` };
  return { ok: true, learning: raw };
}

// ─── Main entry point ─────────────────────────────────────────────────────────

export async function runEvaluation(
  input: EvalInput,
  db: D1Database,
  apiKey: string,
  model: string,
): Promise<{ learningsAccepted: number; learningsRejected: number; qualityScore: number }> {
  const transcript = await loadTranscript(db, input.callId);
  if (!transcript.length) return { learningsAccepted: 0, learningsRejected: 0, qualityScore: 0 };

  const transcriptText = formatTranscript(transcript);
  const metaSummary = formatMeta(input);

  // ── LLM evaluation (forced-tool → guaranteed JSON) ──────────────────────────
  let evalResult: Record<string, unknown>;
  try {
    evalResult = await callForcedTool({
      apiKey,
      model,
      system: EVAL_SYSTEM_PROMPT,
      user: `${metaSummary}\n\n${transcriptText}`,
      tool: EVAL_TOOL,
      maxTokens: 2048,
    });
  } catch (err) {
    console.error(`[eval] LLM error for call ${input.callId}:`, err);
    return { learningsAccepted: 0, learningsRejected: 0, qualityScore: 0 };
  }

  // ── Process learnings ────────────────────────────────────────────────────────
  const rawLearnings = Array.isArray(evalResult.learnings) ? (evalResult.learnings as RawLearning[]) : [];
  let accepted = 0;
  let rejected = 0;
  for (const raw of rawLearnings) {
    const validation = validateLearning(raw);
    if (!validation.ok) {
      console.warn(`[eval] learning "${raw.key}" rejected: ${validation.reason}`);
      rejected++;
      continue;
    }
    try {
      await upsertLearning(db, {
        tenantId: input.tenantId,
        scope: raw.scope,
        key: raw.key,
        category: raw.category,
        applies_state: (raw.applies_state ?? null) as CallState | null,
        applies_caller: (raw.applies_caller ?? null) as CallerType | null,
        instruction: raw.instruction.trim(),
        example_ar: raw.example_ar?.trim() ?? null,
        confidence: raw.confidence,
        newConfidence: raw.confidence,
      });
      accepted++;
    } catch (err) {
      console.error(`[eval] DB error upserting learning "${raw.key}":`, err);
    }
  }

  // ── Update CRM contact ───────────────────────────────────────────────────────
  if (input.callerPhone) {
    const firstName = typeof evalResult.inferred_caller_first_name === 'string' ? evalResult.inferred_caller_first_name.trim().slice(0, 40) || undefined : undefined;
    const gender = typeof evalResult.inferred_caller_gender === 'string' && ['male', 'female', 'unknown'].includes(evalResult.inferred_caller_gender) ? (evalResult.inferred_caller_gender as Gender) : 'unknown';
    const email = typeof evalResult.inferred_caller_email === 'string' ? evalResult.inferred_caller_email.trim().toLowerCase().slice(0, 160) || undefined : undefined;
    const summary = typeof evalResult.call_summary_ar === 'string' ? evalResult.call_summary_ar.trim().slice(0, 300) : undefined;
    await upsertCrmContact(db, input.tenantId, input.callerPhone, {
      firstName,
      gender,
      email,
      lastSummary: summary,
      lastCallAt: input.endedAt,
    });
  }

  return {
    learningsAccepted: accepted,
    learningsRejected: rejected,
    qualityScore: typeof evalResult.overall_quality === 'number' ? evalResult.overall_quality : 0,
  };
}

// ─── Helpers ──────────────────────────────────────────────────────────────────

function formatTranscript(lines: TranscriptLine[]): string {
  return lines.map((l, i) => `[${i + 1}][${l.state}] ${l.role.toUpperCase()}: ${l.text}`).join('\n');
}

function formatMeta(i: EvalInput): string {
  return [
    `=== CALL METADATA ===`,
    `call_id: ${i.callId}`,
    `caller_type: ${i.callerType}`,
    `intent: ${i.intentId ?? 'none'}`,
    `resolved: ${i.intentResolved}`,
    `handed_off: ${i.handedOff}`,
    `end_reason: ${i.endReason}`,
    `duration_sec: ${i.endedAt - i.startedAt}`,
    `total_turns: ${i.totalTurns}`,
    `honorific_guard_hits: ${i.honorificHits}`,
    `msa_marker_hits: ${i.msaHits}`,
    `llm_errors: ${i.llmErrors}`,
  ].join('\n');
}

const EVAL_SYSTEM_PROMPT = `You are a quality-assurance expert for Arabic voice AI agents. You evaluate call transcripts and produce structured, honest assessments.

Language context: the agent should speak natural Cairene Egyptian Arabic with no honorifics (حضرتك, يا فندم, سيادتك are FORBIDDEN). Report any violations as friction points with persona_adherence < 1.

Your learnings MUST be:
- Derived from something that actually happened in this specific transcript.
- Actionable instructions for future calls (not observations or scores).
- Safe: they may only change HOW the agent phrases things, what order it asks in, or how it recovers from confusion. They MUST NOT instruct the agent to skip confirmations, invent facts, claim to be human, or use honorifics.
- Concise: one clear Egyptian-Arabic-friendly sentence each.

Do not invent names, emails or events that do not appear in the transcript. When in doubt, use empty string.`;
