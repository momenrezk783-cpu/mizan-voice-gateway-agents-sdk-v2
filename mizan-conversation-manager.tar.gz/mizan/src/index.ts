// Mizan Conversation Manager — Cloudflare Worker entry point.
//
// Routes:
//   POST /telephony/inbound         telephony bridge → start a new inbound call
//   POST /telephony/outbound        telephony bridge → start a new outbound call
//   WebSocket /call/:callId/ws?token= telephony bridge → real-time audio/text exchange
//
// Queue consumer:
//   EVAL_QUEUE → runEvaluation() per message

import { CallSession } from './call-session';
import { runEvaluation } from './evaluator';
import { lookupCaller, loadTenantConfig } from './db';
import type { Env, CallContext, EvalJob, Arm } from './types';

export { CallSession };

// ─── Helper: HMAC-SHA256 request verification ─────────────────────────────────

async function verifyHmac(req: Request, body: string, secret: string): Promise<boolean> {
  const sig = req.headers.get('x-mizan-signature') ?? '';
  if (!sig) return false;
  const key = await crypto.subtle.importKey('raw', new TextEncoder().encode(secret), { name: 'HMAC', hash: 'SHA-256' }, false, ['verify']);
  const sigBuf = Uint8Array.from(sig.match(/.{2}/g)!.map((h) => parseInt(h, 16)));
  return crypto.subtle.verify('HMAC', key, sigBuf, new TextEncoder().encode(body));
}

// ─── A/B arm assignment (simple deterministic hash + holdout rate) ────────────

function assignArm(callId: string, holdoutRate: number): Arm {
  if (holdoutRate <= 0) return 'treated';
  if (holdoutRate >= 1) return 'holdout';
  // Deterministic from callId: same call always gets same arm (useful for debugging)
  let h = 0x811c9dc5;
  for (let i = 0; i < callId.length; i++) h = Math.imul(h ^ callId.charCodeAt(i), 0x01000193);
  return (h >>> 0) / 0xffffffff < holdoutRate ? 'holdout' : 'treated';
}

// ─── Clock helpers (Egyptian locale) ─────────────────────────────────────────

function buildClock(tz = 'Africa/Cairo'): CallContext['clock'] {
  const now = new Date();
  const fmt = (opts: Intl.DateTimeFormatOptions) => new Intl.DateTimeFormat('ar-EG', { timeZone: tz, ...opts }).format(now);
  const todayIso = new Intl.DateTimeFormat('en-CA', { timeZone: tz }).format(now); // YYYY-MM-DD
  const hour = Number(new Intl.DateTimeFormat('en-US', { timeZone: tz, hour: 'numeric', hour12: false }).format(now));
  const weekday = fmt({ weekday: 'long' });
  const localTime = fmt({ hour: '2-digit', minute: '2-digit', hour12: true });
  const greetingWord = hour < 12 ? 'صباح الخير' : hour < 18 ? 'مساء الخير' : 'مساء الخير';
  return { todayIso, weekday, localTime, timezone: tz, greetingWord };
}

// ─── Build CallContext from telephony payload + D1 ────────────────────────────

interface TelephonyPayload {
  callId: string;
  tenantId: string;
  direction: 'inbound' | 'outbound';
  callerPhone?: string; // E.164 or null
}

async function buildContext(payload: TelephonyPayload, env: Env): Promise<CallContext> {
  const { callId, tenantId, direction, callerPhone = null } = payload;

  const config = await loadTenantConfig(env.DB, tenantId);
  if (!config) throw new Error(`Tenant "${tenantId}" not found or not active.`);

  // CRM look up
  const crm = callerPhone ? await lookupCaller(env.DB, tenantId, callerPhone) : null;

  const ctx: CallContext = {
    callId,
    tenantId,
    direction,
    callerPhone,
    callerType: crm?.callerType ?? 'unknown',
    caller: {
      firstName: crm?.crm.first_name ?? null,
      gender: crm?.crm.gender ?? 'unknown',
      lastSummary: crm?.crm.last_summary ?? null,
      lastCallAt: crm?.crm.last_call_at ?? null,
    },
    business: {
      name: config.businessName,
      agentName: config.agentName,
      agentGender: config.agentGender,
      hours: config.businessHours ?? null,
      knowledge: config.knowledge ?? null,
      handoffNumber: config.handoffNumber ?? null,
    },
    clock: buildClock(config.timezone),
  };
  return ctx;
}

// ─── Worker fetch handler ─────────────────────────────────────────────────────

export default {
  async fetch(request: Request, env: Env): Promise<Response> {
    const url = new URL(request.url);

    // ── Telephony webhook: start a call ──────────────────────────────────────
    if (request.method === 'POST' && (url.pathname === '/telephony/inbound' || url.pathname === '/telephony/outbound')) {
      const rawBody = await request.text();
      if (!(await verifyHmac(request, rawBody, env.WEBHOOK_SECRET)))
        return new Response('Forbidden', { status: 403 });

      let payload: TelephonyPayload;
      try { payload = JSON.parse(rawBody); } catch { return new Response('Bad Request', { status: 400 }); }
      if (!payload.callId || !payload.tenantId)
        return new Response('Missing callId or tenantId', { status: 400 });
      payload.direction = url.pathname.includes('outbound') ? 'outbound' : 'inbound';

      let ctx: CallContext;
      try { ctx = await buildContext(payload, env); }
      catch (err) {
        console.error('[index] buildContext failed', err);
        return new Response(err instanceof Error ? err.message : 'Internal error', { status: 500 });
      }

      const arm = assignArm(payload.callId, Number(env.HOLDOUT_RATE ?? '0'));

      // Init the Durable Object for this call (idempotent — DO wakes if already exists)
      const doId = env.CALL_SESSION.idFromName(payload.callId);
      const stub = env.CALL_SESSION.get(doId);
      const initRes = await stub.fetch(new Request('https://do/init', {
        method: 'POST',
        body: JSON.stringify({ ctx, arm }),
        headers: { 'content-type': 'application/json' },
      }));
      if (!initRes.ok) return new Response('DO init failed', { status: 502 });

      return new Response(JSON.stringify({ callId: payload.callId, arm }), {
        headers: { 'content-type': 'application/json' },
      });
    }

    // ── WebSocket upgrade: live call session ─────────────────────────────────
    const wsMatch = url.pathname.match(/^\/call\/([^/]+)\/ws$/);
    if (wsMatch) {
      if (request.headers.get('upgrade')?.toLowerCase() !== 'websocket')
        return new Response('Expected WebSocket upgrade', { status: 426 });

      const callId = wsMatch[1];
      const doId = env.CALL_SESSION.idFromName(callId);
      const stub = env.CALL_SESSION.get(doId);
      return stub.fetch(request); // the DO handles the WS upgrade
    }

    // ── Health ───────────────────────────────────────────────────────────────
    if (url.pathname === '/health') {
      return new Response(JSON.stringify({ ok: true, ts: Date.now() }), { headers: { 'content-type': 'application/json' } });
    }

    return new Response('Not found', { status: 404 });
  },

  // ─── Queue consumer: post-call evaluation ─────────────────────────────────
  async queue(batch: MessageBatch<EvalJob>, env: Env): Promise<void> {
    for (const msg of batch.messages) {
      const { callId, tenantId } = msg.body;
      try {
        // Retrieve full call metadata stored in D1
        const row = await env.DB
          .prepare(
            `SELECT caller_phone, caller_type, arm, started_at, ended_at, end_reason,
                    total_turns, intent_id, intent_resolved, handed_off,
                    honorific_hits, msa_hits, llm_errors
             FROM   calls WHERE id = ?1`,
          )
          .bind(callId)
          .first<{
            caller_phone: string | null; caller_type: string; arm: string;
            started_at: number; ended_at: number; end_reason: string; total_turns: number;
            intent_id: string | null; intent_resolved: number; handed_off: number;
            honorific_hits: number; msa_hits: number; llm_errors: number;
          }>();

        if (!row) { msg.ack(); continue; }

        await runEvaluation(
          {
            callId, tenantId,
            callerPhone: row.caller_phone,
            callerType: row.caller_type as any,
            arm: row.arm as any,
            startedAt: row.started_at * 1000, // D1 stores UNIX epoch seconds
            endedAt:   row.ended_at   * 1000,
            endReason: row.end_reason,
            totalTurns: row.total_turns,
            intentId: row.intent_id,
            intentResolved: !!row.intent_resolved,
            handedOff: !!row.handed_off,
            honorificHits: row.honorific_hits,
            msaHits: row.msa_hits,
            llmErrors: row.llm_errors,
            finalSlots: {}, // slots were serialised into the transcript; evaluator reads those
          },
          env.DB,
          env.ANTHROPIC_API_KEY,
          env.EVALUATOR_MODEL,
        );
        msg.ack();
      } catch (err) {
        console.error(`[queue] eval failed for ${callId}:`, err);
        msg.retry(); // CF will retry up to the queue's max_retries
      }
    }
  },
} satisfies ExportedHandler<Env>;
