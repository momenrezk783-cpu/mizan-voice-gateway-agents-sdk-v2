// Thin provider adapter (Anthropic Messages API). Swap this file to change providers;
// nothing else in the codebase knows about SSE framing or wire formats.

const API_URL = 'https://api.anthropic.com/v1/messages';
const API_VERSION = '2023-06-01';

export type TextBlock = { type: 'text'; text: string };
export type ToolUseBlock = { type: 'tool_use'; id: string; name: string; input: Record<string, unknown> };
export type ToolResultBlock = { type: 'tool_result'; tool_use_id: string; content: string; is_error?: boolean };
export type Block = TextBlock | ToolUseBlock | ToolResultBlock;
export interface Msg {
  role: 'user' | 'assistant';
  content: string | Block[];
}
export interface SystemBlock {
  type: 'text';
  text: string;
  cache_control?: { type: 'ephemeral' };
}
export interface ToolSchema {
  name: string;
  description: string;
  input_schema: Record<string, unknown>;
}

export class LLMError extends Error {
  constructor(public status: number, message: string) {
    super(`LLM ${status}: ${message}`);
  }
}

export interface StreamOpts {
  apiKey: string;
  model: string;
  system: SystemBlock[];
  messages: Msg[];
  tools: ToolSchema[];
  maxTokens: number;
  signal: AbortSignal;
  onStart?: () => void; // first SSE event received (used to cancel the TTFB timeout)
  onText: (delta: string) => void; // called for every text delta → goes to the sentence chunker → TTS
}

export interface LLMResult {
  content: Array<TextBlock | ToolUseBlock>;
  stopReason: string;
}

export async function streamCompletion(o: StreamOpts): Promise<LLMResult> {
  const res = await fetch(API_URL, {
    method: 'POST',
    signal: o.signal,
    headers: { 'content-type': 'application/json', 'x-api-key': o.apiKey, 'anthropic-version': API_VERSION },
    body: JSON.stringify({ model: o.model, max_tokens: o.maxTokens, system: o.system, messages: o.messages, tools: o.tools, stream: true }),
  });
  if (!res.ok || !res.body) throw new LLMError(res.status, (await res.text().catch(() => '')).slice(0, 300));

  type Acc = { type: 'text'; text: string } | { type: 'tool_use'; id: string; name: string; json: string };
  const blocks = new Map<number, Acc>();
  let stopReason = '';

  const handle = (ev: any) => {
    switch (ev.type) {
      case 'message_start':
        o.onStart?.();
        break;
      case 'content_block_start': {
        const b = ev.content_block;
        blocks.set(ev.index, b.type === 'tool_use' ? { type: 'tool_use', id: b.id, name: b.name, json: '' } : { type: 'text', text: '' });
        break;
      }
      case 'content_block_delta': {
        const b = blocks.get(ev.index);
        if (!b) break;
        if (ev.delta.type === 'text_delta' && b.type === 'text') {
          b.text += ev.delta.text;
          o.onText(ev.delta.text);
        } else if (ev.delta.type === 'input_json_delta' && b.type === 'tool_use') {
          b.json += ev.delta.partial_json;
        }
        break;
      }
      case 'message_delta':
        stopReason = ev.delta?.stop_reason ?? stopReason;
        break;
      case 'error':
        throw new LLMError(500, ev.error?.message ?? 'stream error');
    }
  };

  const reader = res.body.pipeThrough(new TextDecoderStream()).getReader();
  let buf = '';
  for (;;) {
    const { value, done } = await reader.read();
    if (done) break;
    buf += value.replace(/\r\n/g, '\n');
    let sep: number;
    while ((sep = buf.indexOf('\n\n')) >= 0) {
      const frame = buf.slice(0, sep);
      buf = buf.slice(sep + 2);
      const data = frame.split('\n').find((l) => l.startsWith('data:'));
      if (data) handle(JSON.parse(data.slice(5).trim()));
    }
  }

  const content: LLMResult['content'] = [];
  for (const [, b] of [...blocks.entries()].sort((a, c) => a[0] - c[0])) {
    if (b.type === 'text') {
      if (b.text) content.push({ type: 'text', text: b.text });
    } else {
      let input: Record<string, unknown> = {};
      try { input = b.json ? JSON.parse(b.json) : {}; } catch { /* malformed tool JSON → empty input; the executor will reject it */ }
      content.push({ type: 'tool_use', id: b.id, name: b.name, input });
    }
  }
  return { content, stopReason };
}

/** Non-streaming call that FORCES a single tool → guaranteed schema-shaped JSON (used by the evaluator). */
export async function callForcedTool(o: {
  apiKey: string; model: string; system: string; user: string; tool: ToolSchema; maxTokens: number;
}): Promise<Record<string, unknown>> {
  const res = await fetch(API_URL, {
    method: 'POST',
    headers: { 'content-type': 'application/json', 'x-api-key': o.apiKey, 'anthropic-version': API_VERSION },
    body: JSON.stringify({
      model: o.model,
      max_tokens: o.maxTokens,
      system: o.system,
      tools: [o.tool],
      tool_choice: { type: 'tool', name: o.tool.name },
      messages: [{ role: 'user', content: o.user }],
    }),
  });
  if (!res.ok) throw new LLMError(res.status, (await res.text().catch(() => '')).slice(0, 300));
  const json = (await res.json()) as { content: Array<{ type: string; input?: Record<string, unknown> }> };
  const block = json.content.find((b) => b.type === 'tool_use');
  if (!block?.input) throw new LLMError(502, 'no tool_use block in response');
  return block.input;
}
