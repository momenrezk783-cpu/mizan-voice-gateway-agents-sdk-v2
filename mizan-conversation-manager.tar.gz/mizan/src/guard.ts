// Output guard — the deterministic last line of defence between the LLM and the TTS engine.
// The prompt asks the model not to use honorifics / MSA; this file ENFORCES it for honorifics
// and MEASURES it for MSA. No Workers APIs in here, so it is unit-testable in plain Node.

// Arabic LETTERS only (excludes punctuation like ، U+060C, harakat, digits).
// \b does not work for Arabic, so we build our own word-boundary lookarounds.
const AR = '\\u0621-\\u063A\\u0641-\\u064A\\u0671-\\u06D3'; // Arabic letter ranges only
const L = `(?<![${AR}])`; // "not preceded by an Arabic letter" = word-start
const R = `(?![${AR}])`; // "not followed by an Arabic letter"  = word-end
const re = (src: string) => new RegExp(src, 'gu');

const MARKS = /[\u064B-\u065F\u0670\u0640]/g; // harakat + tatweel
export const stripMarks = (s: string) => s.replace(MARKS, '');
const norm = (s: string) =>
  stripMarks(s)
    .replace(/[أإآ]/g, 'ا')
    .replace(/ى/g, 'ي')
    .replace(/ة/g, 'ه');

interface Rule {
  label: string;
  rx: RegExp;
  to: string;
}

// Order matters: multi-word forms first. Replacements keep the sentence grammatical
// ("أهلاً بحضرتك" → "أهلا بيك"). This is a safety net, not the primary mechanism.
const RULES: Rule[] = [
  { label: 'ya_fandem', rx: re(`${L}يا\\s*(?:أ|ا)?فندم${R}`), to: '' },
  { label: 'fandem', rx: re(`${L}(?:أ|ا)?فندم${R}`), to: '' },
  {
    label: 'vocative_title',
    rx: re(`${L}يا\\s*(?:باشا|بيه|بك|هانم|باشمهندس|معلم|(?:أ|ا)ستاذ[ةه]?|دكتور[ةه]?|مهندس[ةه]?)${R}`),
    to: '',
  },
  // Multi-word + preposition forms — no word-boundary check needed (the preposition anchors them)
  { label: 'hadretak', rx: re(`مع\\s+حضرتك`),  to: 'معاك' },
  { label: 'hadretak', rx: re(`عند\\s+حضرتك`), to: 'عندك' },
  { label: 'hadretak', rx: re(`من\\s+حضرتك`),  to: 'منك'  },
  // Clitic-prefix forms: ل/ب are attached, so look for word-start before the prefix letter
  { label: 'hadretak', rx: re(`${L}لحضرتك${R}`),  to: 'ليك'  },
  { label: 'hadretak', rx: re(`${L}بحضرتك${R}`),  to: 'بيك'  },
  // Plain forms (most specific first)
  { label: 'hadretak', rx: re(`${L}حضرتكم${R}`),  to: 'إنتو' },
  { label: 'hadretak', rx: re(`${L}([وف]?)حضرتك${R}`), to: '$1إنت' },
  { label: 'sayadtak', rx: re(`${L}(?:سيادتكم|سعادتكم)${R}`), to: 'إنتو' },
  { label: 'sayadtak', rx: re(`${L}([وف]?)(?:سيادتك|سعادتك)${R}`), to: '$1إنت' },
];

export interface SanitizeResult {
  text: string;
  violations: string[];
}

export function sanitizeForSpeech(input: string): SanitizeResult {
  let text = stripMarks(input);
  const violations: string[] = [];
  for (const r of RULES) {
    const next = text.replace(r.rx, r.to);
    if (next !== text) violations.push(r.label);
    text = next;
  }
  if (violations.length) {
    text = text
      .replace(/\s{2,}/g, ' ')
      .replace(/\s+([،,.!؟?؛])/g, '$1')
      .replace(/^[\s،,]+/, '');
  }
  return { text: text.trim(), violations };
}

/** True if the text contains a banned address form (used to reject learnings that would teach one). */
export function containsBannedAddress(text: string): boolean {
  const t = stripMarks(text);
  return RULES.some((r) => t.replace(r.rx, '') !== t);
}

// MSA / non-Egyptian markers. Metric only: we cannot rewrite dialect deterministically in real time,
// so we count, log, and let the post-call evaluator + learnings loop deal with it.
const MSA_WORDS = [
  'ماذا', 'لماذا', 'كيف', 'سوف', 'الآن', 'أريد', 'تريد', 'أستطيع', 'يمكنني', 'بالطبع',
  'يسعدني', 'لا تتردد', 'هل', 'ليس', 'حسناً', 'نعم', 'عزيزي', 'عزيزتي',
];
const MSA_RX: Array<[string, RegExp]> = MSA_WORDS.map((w) => [w, new RegExp(`${L}${norm(w)}${R}`, 'u')]);

export function detectNonEgyptian(text: string): string[] {
  const t = norm(text);
  return MSA_RX.filter(([, rx]) => rx.test(t)).map(([w]) => w);
}

/**
 * Buffers streamed LLM deltas and releases them at natural prosodic boundaries so the TTS
 * gets whole phrases (better intonation) while first audio starts after the first sentence.
 * Cuts only at punctuation, so multi-word banned phrases can never straddle two chunks.
 */
export class SpeechChunker {
  #buf = '';
  constructor(private readonly onChunk: (text: string) => void) {}

  push(delta: string): void {
    this.#buf += delta;
    for (;;) {
      const cut = this.#findCut();
      if (cut < 0) return;
      const piece = this.#buf.slice(0, cut + 1);
      this.#buf = this.#buf.slice(cut + 1);
      if (piece.trim()) this.onChunk(piece);
    }
  }

  flush(): void {
    const rest = this.#buf;
    this.#buf = '';
    if (rest.trim()) this.onChunk(rest);
  }

  discard(): void {
    this.#buf = '';
  }

  #findCut(): number {
    const b = this.#buf;
    for (let i = 0; i < b.length; i++) {
      const c = b[i];
      if (c === '!' || c === '?' || c === '؟' || c === '\n') return i;
      if (c === '.' && i + 1 < b.length && /\s/.test(b[i + 1])) return i; // "3.5" and "a.b@x" don't split
      if ((c === '،' || c === ',' || c === '؛') && i >= 45) return i; // long clause: release early
    }
    return -1;
  }
}
