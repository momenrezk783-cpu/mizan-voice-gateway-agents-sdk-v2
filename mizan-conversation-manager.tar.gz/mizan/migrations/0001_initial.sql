-- Mizan Consult — initial D1 schema
-- Apply with: wrangler d1 migrations apply mizan-db --remote
-- All timestamps: UNIX epoch seconds (INTEGER). IDs: UUID strings.

PRAGMA journal_mode = WAL;
PRAGMA foreign_keys = ON;

-- ─── Tenants ────────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS tenants (
  id          TEXT    PRIMARY KEY,
  name        TEXT    NOT NULL,
  config_json TEXT    NOT NULL,          -- TenantConfig (JSON)
  active      INTEGER NOT NULL DEFAULT 1, -- 0 = suspended
  created_at  INTEGER NOT NULL DEFAULT (unixepoch()),
  updated_at  INTEGER NOT NULL DEFAULT (unixepoch())
);

-- ─── CRM contacts ───────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS crm_contacts (
  id           TEXT    PRIMARY KEY,
  tenant_id    TEXT    NOT NULL REFERENCES tenants(id),
  phone        TEXT    NOT NULL,          -- E.164 e.g. 01012345678
  first_name   TEXT,
  gender       TEXT    NOT NULL DEFAULT 'unknown' CHECK (gender IN ('male','female','unknown')),
  email        TEXT,
  last_call_at INTEGER,
  last_summary TEXT,                      -- max ~300 chars, Egyptian Arabic
  created_at   INTEGER NOT NULL DEFAULT (unixepoch()),
  updated_at   INTEGER NOT NULL DEFAULT (unixepoch()),
  deleted_at   INTEGER,
  UNIQUE (tenant_id, phone)
);
CREATE INDEX IF NOT EXISTS crm_tenant_phone ON crm_contacts (tenant_id, phone) WHERE deleted_at IS NULL;

-- ─── Calls ──────────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS calls (
  id               TEXT    PRIMARY KEY,  -- telephony call UUID
  tenant_id        TEXT    NOT NULL REFERENCES tenants(id),
  caller_phone     TEXT,
  direction        TEXT    NOT NULL CHECK (direction IN ('inbound','outbound')),
  arm              TEXT    NOT NULL DEFAULT 'treated' CHECK (arm IN ('treated','holdout','disabled')),
  prompt_version   TEXT    NOT NULL DEFAULT '1',
  started_at       INTEGER NOT NULL DEFAULT (unixepoch()),
  ended_at         INTEGER,
  end_reason       TEXT,
  duration_sec     INTEGER,
  total_turns      INTEGER,
  caller_type      TEXT    NOT NULL DEFAULT 'unknown',
  intent_id        TEXT,
  intent_resolved  INTEGER NOT NULL DEFAULT 0,
  handed_off       INTEGER NOT NULL DEFAULT 0,
  honorific_hits   INTEGER NOT NULL DEFAULT 0,
  msa_hits         INTEGER NOT NULL DEFAULT 0,
  llm_errors       INTEGER NOT NULL DEFAULT 0
);
CREATE INDEX IF NOT EXISTS calls_tenant_started ON calls (tenant_id, started_at DESC);
CREATE INDEX IF NOT EXISTS calls_eval ON calls (ended_at) WHERE ended_at IS NOT NULL AND intent_resolved IS NOT NULL;

-- ─── Transcript lines ────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS transcript_lines (
  id          TEXT    PRIMARY KEY,
  call_id     TEXT    NOT NULL REFERENCES calls(id) ON DELETE CASCADE,
  role        TEXT    NOT NULL CHECK (role IN ('caller','agent')),
  text        TEXT    NOT NULL,
  state       TEXT    NOT NULL,
  ts          INTEGER NOT NULL,
  interrupted INTEGER NOT NULL DEFAULT 0
);
CREATE INDEX IF NOT EXISTS tl_call ON transcript_lines (call_id, ts);

-- ─── Learnings ──────────────────────────────────────────────────────────────
-- key         stable slug, e.g. "phone_collection_strategy"
-- scope       global (any tenant) | tenant (this tenant only)
-- tenant_id   the tenant it was extracted from (even for scope='global', for attribution)
-- confidence  float 0–1, updated on each upsert
-- support_count how many calls contributed to this learning
-- applies_state  NULL = any state
-- applies_caller NULL = any caller type
CREATE TABLE IF NOT EXISTS learnings (
  id              TEXT    PRIMARY KEY,
  tenant_id       TEXT    NOT NULL REFERENCES tenants(id),
  scope           TEXT    NOT NULL CHECK (scope IN ('global','tenant')),
  key             TEXT    NOT NULL,       -- snake_case slug
  category        TEXT    NOT NULL,       -- phrasing | ordering | pacing | recovery | confirmation | intent_detection
  applies_state   TEXT    CHECK (applies_state IN ('GREETING','DATA_COLLECTION','ACTION','CLOSING')),
  applies_caller  TEXT    CHECK (applies_caller IN ('new_lead','returning_customer')),
  instruction     TEXT    NOT NULL,
  example_ar      TEXT,
  confidence      REAL    NOT NULL DEFAULT 0.5,
  support_count   INTEGER NOT NULL DEFAULT 1,
  created_at      INTEGER NOT NULL DEFAULT (unixepoch()),
  updated_at      INTEGER NOT NULL DEFAULT (unixepoch()),
  deleted_at      INTEGER,
  UNIQUE (tenant_id, scope, key)
);
CREATE INDEX IF NOT EXISTS learnings_active ON learnings (scope, tenant_id, confidence DESC, applies_state)
  WHERE deleted_at IS NULL;

-- ─── Seed: demo tenant ───────────────────────────────────────────────────────
-- Remove or replace before production deployment.
INSERT OR IGNORE INTO tenants (id, name, config_json) VALUES (
  'demo-tenant',
  'عيادة ميزان',
  json('{
    "businessName": "عيادة ميزان",
    "agentName": "نور",
    "agentGender": "female",
    "timezone": "Africa/Cairo",
    "businessHours": "الأحد للخميس من الساعة ٩ الصبح لـ ٥ المساء",
    "knowledge": "بنقدم استشارات طبية عامة وحجوزات كشف مع دكتور كريم. سعر الكشف ٣٠٠ جنيه. الكشف ساعة. ممكن تلغي أو تعدل ميعادك لحد ٢٤ ساعة قبله.",
    "handoffNumber": "+201001234567",
    "actionWebhookUrl": "https://hooks.example.com/mizan/actions"
  }')
);
